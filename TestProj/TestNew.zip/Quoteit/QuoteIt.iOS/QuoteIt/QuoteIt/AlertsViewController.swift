//
//  AlertsViewController.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-28.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class AlertsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var alertsTableView: UITableView!
    @IBOutlet weak var alertsActivityIndicatorView: UIActivityIndicatorView!
    
    let refreshController = UIRefreshControl()
    var alertsArray: [AlertData] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "ALERTS"
        setMenuButton()
        loadAlerts()
        
        alertsTableView.tableFooterView = UIView()
        refreshController.addTarget(self, action: #selector(loadAlerts), for: UIControlEvents.valueChanged)
        alertsTableView.addSubview(refreshController)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func loadAlerts() {
        alertsActivityIndicatorView.startAnimating()
        UserService.getUserAlert { (alerts, error) in
            self.alertsActivityIndicatorView.stopAnimating()
            if let error = error {
                self.showSlidingErrorMessage(errorString: error.message)
            } else {
                self.alertsArray.append(contentsOf: alerts)
            }
            self.alertsTableView.reloadData()
            self.refreshController.endRefreshing()
        }
    }
    
    
    // MARK:- UITableView Delegate Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alertsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AlertTableViewCell") as! AlertTableViewCell
        let alertData = alertsArray[indexPath.row]
        cell.updateView(alertData: alertData)
        return cell
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
