//
//  MediaTypes.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation

enum MediaTypes: Int {
    case image = 1
    case thumbnail = 2
    case video = 3
    case audio = 4
    case url = 5
}
