//
//  QIImageViewExtension.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import UIKit

extension UIImageView {
    
    func roundImage() {
        self.layer.cornerRadius = self.frame.size.height/2.0
        self.clipsToBounds = true
    }
}
