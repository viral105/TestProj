//
//  ReplyViewModel.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper
class ReplyViewModel: Mappable {
    var id: Int?
    var posterId: String?
    var repliedBy: UserProfileViewModel?
    var replyDetail: String?
    var dateReplied: Date = Date()
    var approved: Bool = true
    var commentId: Int?
    var jobId: Int?
    var replyImage: String?
    
    required init(map: Mapper) throws {
        try id = map.from("id")
        posterId = map.optionalFrom("posterId")
        repliedBy = map.optionalFrom("repliedBy")
        replyDetail = map.optionalFrom("replyDetail")
        dateReplied = map.parseDate("dateReplied")
        let approvedOptional: Bool? = map.optionalFrom("approved")
        if let approvedOptional = approvedOptional {
            approved = approvedOptional
        }
        commentId = map.optionalFrom("commentId")
        jobId = map.optionalFrom("jobId")
        replyImage = map.optionalFrom("replyImage")
        
    }
}
