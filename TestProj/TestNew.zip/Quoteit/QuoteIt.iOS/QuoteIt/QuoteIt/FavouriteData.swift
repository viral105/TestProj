//
//  FavouriteData.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-09-13.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

class FavouriteData: Mappable {
    var favId: Int?
    var jobID: Int?
    var userId: String?
    var dateAdded: Date = Date()
    var notes: String?
    var jobTitle: String?
    var jobCategory: Int?
    var jobDetails: Int?
    var address: String?
    var poster: UserProfileViewModel?
    

    required init(map: Mapper) throws {
        try favId = map.from("favID")
        jobID = map.optionalFrom("jobID")
        userId = map.optionalFrom("userId")
        dateAdded = map.parseDate("dateAdded")
        
        notes = map.optionalFrom("notes")
        jobTitle = map.optionalFrom("jobTitle")
        jobCategory = map.optionalFrom("jobCategory")
        jobDetails = map.optionalFrom("jobDetails")
        address = map.optionalFrom("address")
        poster = map.optionalFrom("poster")
        
    }
    
    
}
