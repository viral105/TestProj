//
//  AccountType.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
enum AccountType: Int {
    case business = 2
    case user = 3
}
