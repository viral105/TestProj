//
//  DashboardService.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-09-13.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Alamofire

class DashboardService {
    
    static func getMyJobs(searchType: JobSearchType, completion: @escaping (_ jobs: [JobViewModel],_ error: QIError?) -> Void) {
        let url = "\(BASE_URL)\(GET_DASHBOARD_JOBS)"
        
        let searchCriteriaViewModel = SearchCriteriaViewModel()
        searchCriteriaViewModel.searchType = searchType
        let perameters = searchCriteriaViewModel.encodeToJSON()
        
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = HTTPMethod.post.rawValue
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        
        let pjson = Global.jsonToString(json: perameters as AnyObject)
        let data = (pjson?.data(using: .utf8))! as Data
        
        request.httpBody = data
        request.allHTTPHeaderFields = UserService.getHTTPHeaders()
        
        Alamofire.request(request).responseJSON { (response) in
            var jobs: [JobViewModel] = []
            if let jsonResponse = response.result.value as? NSDictionary {
                print("jsonResponse \(jsonResponse)")
                if let error = QIError.parseFromJson(json: jsonResponse) {
                    completion(jobs, error)
                }
            } else {
                if let jobsJsonArray = response.result.value as? [NSDictionary] {
                    for jobDictionary in jobsJsonArray {
                        if let jobData = JobViewModel.from(jobDictionary) {
                            jobs.append(jobData)
                        }
                        
                    }
                }
                completion(jobs, nil)
            }
        }
    }
    
    static func loadHistories(completion: @escaping (_ jobs: [JobViewModel],_ error: QIError?) -> Void) {
        let url = "\(BASE_URL)\(GET_HIRSOTIES)"
        
        Alamofire.request(url, method: HTTPMethod.get, parameters: nil, headers: UserService.getHTTPHeaders()).responseJSON { (response) in
            var jobs: [JobViewModel] = []
            if let jsonResponse = response.result.value as? NSDictionary {
                if let error = QIError.parseFromJson(json: jsonResponse) {
                    completion(jobs, error)
                }
            } else {
                if let jobsJsonArray = response.result.value as? [NSDictionary] {
                    for jobDictionary in jobsJsonArray {
                        let jobData = JobViewModel.from(jobDictionary)
                        jobs.append(jobData!)
                    }
                }
                completion(jobs, nil)
            }
        }
    }
    
    
    static func loadFavoutires(completion: @escaping (_ favourites: [FavouriteData],_ error: QIError?) -> Void) {
        let url = "\(BASE_URL)\(GET_FAVOURITE)"
        
        Alamofire.request(url, method: HTTPMethod.get, parameters: nil, headers: UserService.getHTTPHeaders()).responseJSON { (response) in
            var favourites: [FavouriteData] = []
            //print("response.result.value \(response.result.value)")
            if let jsonResponse = response.result.value as? NSDictionary {
                if let error = QIError.parseFromJson(json: jsonResponse) {
                    completion(favourites, error)
                }
            } else {
                if let jobsJsonArray = response.result.value as? [NSDictionary] {
                    for jobDictionary in jobsJsonArray {
                        let favouriteData = FavouriteData.from(jobDictionary)
                        favourites.append(favouriteData!)
                    }
                }
                completion(favourites, nil)
            }
        }
    }
}
