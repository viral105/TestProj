//
//  CacheService.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-20.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Alamofire

class CacheService {
    static var keywordList: [KeywordData] = []
    static var citiesList: [AddressData] = []
    static var detailCitiesList: [AddressData] = []
    static var categoriesList: [CategoryData] = []
    
    
    static func getKeyWords(complete: @escaping (_ error: QIError? ) -> Void) {
        print("\(BASE_URL)\(GET_KEY_WORD_LIST)")
        Alamofire.request("\(BASE_URL)\(GET_KEY_WORD_LIST)").responseJSON { (response) in
            keywordList.removeAll()
            if let json = response.result.value, let keywordsArray = json as? [[String: Any]] {
                for jsonObject in keywordsArray {
                    let keywordData = KeywordData(withDictionary: jsonObject)
                    keywordList.append(keywordData)
                }
            }
            print("keywordList count \(keywordList.count)")
            // TODO:- send error
            complete(nil)
        }
    }
    
    static func getCities(complete: @escaping (_ error: QIError? ) -> Void) {
        Alamofire.request("\(BASE_URL)\(GET_CITY_LIST)").responseJSON { (response) in
            citiesList.removeAll()
            if let json = response.result.value, let addressArray = json as? [NSDictionary] {
                for jsonObject in addressArray {
                    if let addressData = AddressData.from(jsonObject) {
                        citiesList.append(addressData)
                    }
                }
            }
            print("citiesList count \(citiesList.count)")
            // TODO:- send error
            complete(nil)
        }
    }
    
    
    static func getDetailCities(complete: @escaping (_ error: QIError? ) -> Void) {
        Alamofire.request("\(BASE_URL)\(GET_DETAIL_CITY_LIST)").responseJSON { (response) in
            detailCitiesList.removeAll()
            if let json = response.result.value, let addressArray = json as? [NSDictionary] {
                for jsonObject in addressArray {
                    if let addressData = AddressData.from(jsonObject) {
                        detailCitiesList.append(addressData)
                    }
                }
            }
            print("detailCitiesList count \(detailCitiesList.count)")
            // TODO:- send error
            complete(nil)
        }
    }
    
    
    static func getCategories(complete: @escaping (_ error: QIError? ) -> Void) {
        Alamofire.request("\(BASE_URL)\(GET_CATEGORY_LIST)").responseJSON { (response) in
            categoriesList.removeAll()
            if let json = response.result.value, let categoryArray = json as? [NSDictionary] {
                for jsonObject in categoryArray {
                    if let categoryData = CategoryData.from(jsonObject) {
                        categoriesList.append(categoryData)
                    }
                }
            }
            print("categoriesList count \(categoriesList.count)")
            // TODO:- send error
            complete(nil)
        }
    }
    
}
