//
//  JobsService.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Alamofire

class JobsService {
    static func loadJobs(completion: @escaping (_ jobs: [JobsFeedViewModel],_ error: QIError?) -> Void) {
        let url = "\(BASE_URL)\(GET_JOB_LIST)"
        let searchCriteriaViewModel = SearchCriteriaViewModel()
        searchCriteriaViewModel.city = "Hamilton"
        searchCriteriaViewModel.category = 0
        searchCriteriaViewModel.lat = 0.0
        searchCriteriaViewModel.lng = 0.0
        searchCriteriaViewModel.page = 1
        searchCriteriaViewModel.pageSize = 100
        
        let perameters = searchCriteriaViewModel.encodeToJSON()
        
        
        
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = HTTPMethod.post.rawValue
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let pjson = Global.jsonToString(json: perameters as AnyObject)
        let data = (pjson?.data(using: .utf8))! as Data
        
        request.httpBody = data
        
        request.allHTTPHeaderFields = UserService.getHTTPHeaders()
        
        Alamofire.request(request).responseJSON { (response) in
            var jobs: [JobsFeedViewModel] = []
            if let jsonResponse = response.result.value as? NSDictionary {
                if let error = QIError.parseFromJson(json: jsonResponse) {
                    completion(jobs, error)
                }
            } else {
                if let jobsJsonArray = response.result.value as? [NSDictionary] {
                    for jobDictionary in jobsJsonArray {
                        if let jobData = JobsFeedViewModel.from(jobDictionary) {
                            jobs.append(jobData)
                        }
                        
                    }
                }
                completion(jobs, nil)
            }
        }
        
    }
    
    static func getJobDetail(jobId: Int, completion:@escaping (_ jobViewModel: JobViewModel?, _ error:QIError?) -> Void) {
        let url = "\(BASE_URL)\(GET_JOB_DETAIL)"
        
        let perameters = ["id": String(format: "%d", jobId)]
        Alamofire.request(url, method: HTTPMethod.get, parameters: perameters, headers: UserService.getHTTPHeaders()).responseJSON { (response) in
            print("response \(String(describing: response.value))")
            if let jsonResponse = response.result.value as? NSDictionary {
                if let error = QIError.parseFromJson(json: jsonResponse) {
                    completion(nil, error)
                } else {
                    let jobViewModel = JobViewModel.from(jsonResponse)
                    for i in 0...(jobViewModel?.comments.count)!-1 {
                        print(jobViewModel?.reviews.count ?? "def 2")
                    }
                    
                    
                    completion(jobViewModel, nil)
                }
            } else {
                completion(nil, nil)
            }
        }
    }
}
