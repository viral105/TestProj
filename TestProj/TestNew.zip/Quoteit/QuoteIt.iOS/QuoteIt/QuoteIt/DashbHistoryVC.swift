//
//  DashbHistory.swift
//  QuoteIt
//
//  Created by Viral Narshana on 9/10/17.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class DashbHistoryVC: UIViewController {

    @IBOutlet weak var historyTableView: UITableView!
    @IBOutlet weak var historyActivityIndicatorView: UIActivityIndicatorView!
    
    let refreshController = UIRefreshControl()
    var historyArray: [JobViewModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        
        refreshController.addTarget(self, action: #selector(loadHistories), for: UIControlEvents.valueChanged)
        historyTableView.addSubview(refreshController)
        
        loadHistories()
    }
    
    func loadHistories() {
        historyActivityIndicatorView.startAnimating()
        DashboardService.loadHistories { (jobs, error) in
            self.historyActivityIndicatorView.stopAnimating()
            if let error = error {
                self.showSlidingErrorMessage(errorString: error.message)
            } else {
                self.historyArray.append(contentsOf: jobs)
                
                print(self.historyArray[0])
            }
            self.historyTableView.reloadData()
            self.refreshController.endRefreshing()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension DashbHistoryVC: UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return historyArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        let historyData = historyArray[indexPath.row]
        if (historyData.assignedToSP != nil) {
            return 280
        }
        else{
            return 170
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: DashboardTblCell
        let historyData = historyArray[indexPath.row]
        if (historyData.assignedToSP != nil) {
            cell = tableView.dequeueReusableCell(withIdentifier: "HistoryAssignToSpCell") as! DashboardTblCell
            
            cell.updateHistoryView(historyData: historyData)
        }
        else{
            cell = tableView.dequeueReusableCell(withIdentifier: "HistoryCell") as! DashboardTblCell
            
            cell.updateHistoryView(historyData: historyData)
        }
        return cell
    }
}
