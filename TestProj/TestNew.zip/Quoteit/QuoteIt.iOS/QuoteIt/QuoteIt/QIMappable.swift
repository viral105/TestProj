//
//  QIMappable.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

extension Mapper {
    func parseDate(_ key: String) -> Date {
        var date = Date()
        let serverDateString: String? = optionalFrom(key)
        if let serverDateString = serverDateString {
            if let dateFromServerString = Date.getDateFromServerString(dateString: serverDateString) {
                date = dateFromServerString
            }
        }
        return date
    }
}
