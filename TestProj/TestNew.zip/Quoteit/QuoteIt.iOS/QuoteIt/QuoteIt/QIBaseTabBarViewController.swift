//
//  QIBaseTabBarViewController.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-28.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class QIBaseTabBarViewController: UITabBarController {

    var jobsTabView: QITabView? = nil
    var getQuotesTabView: QITabView? = nil
    var dashboardTabView: QITabView? = nil
    var alertsTabView: QITabView? = nil
    
    var TAB_BAR_HEIGHT: CGFloat = 70
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTabBar()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillLayoutSubviews() {
        let height: CGFloat = TAB_BAR_HEIGHT
        self.tabBar.frame = CGRect(x: self.view.frame.origin.x, y: self.view.frame.size.height - height, width: self.view.frame.size.width, height: height)
    }
    
    func setupTabBar() {
        var xPostion: CGFloat = 0
        let yPosition: CGFloat = 0
        let tabWidth: CGFloat = self.view.frame.size.width/4.0
        let tabHeight = TAB_BAR_HEIGHT
        
        jobsTabView = QITabView(frame: CGRect(x: xPostion, y: yPosition, width: tabWidth, height: tabHeight))
        jobsTabView?.title = "JOBS"
        jobsTabView?.selected = true
        jobsTabView?.imageName = "tab_icon_jobs"
        jobsTabView?.selectTab = { () in
            self.jobsTabView?.selected = true
            self.getQuotesTabView?.selected = false
            self.dashboardTabView?.selected = false
            self.alertsTabView?.selected = false
            self.selectedIndex = 0
        }
        self.tabBar.addSubview(jobsTabView!)
        
        xPostion += tabWidth
        
        getQuotesTabView = QITabView(frame: CGRect(x: xPostion, y: yPosition, width: tabWidth, height: tabHeight))
        getQuotesTabView?.title = "GET QUOTES"
        getQuotesTabView?.selected = false
        getQuotesTabView?.imageName = "tab_icon_get_quotes"
        getQuotesTabView?.selectTab = { () in
            self.jobsTabView?.selected = false
            self.getQuotesTabView?.selected = true
            self.dashboardTabView?.selected = false
            self.alertsTabView?.selected = false
            self.selectedIndex = 1
        }
        self.tabBar.addSubview(getQuotesTabView!)
        
        xPostion += tabWidth
        
        dashboardTabView = QITabView(frame: CGRect(x: xPostion, y: yPosition, width: tabWidth, height: tabHeight))
        dashboardTabView?.title = "DASHBOARD"
        dashboardTabView?.imageName = "tab_icon_dash"
        dashboardTabView?.selected = false
        dashboardTabView?.selectTab = { () in
            self.jobsTabView?.selected = false
            self.getQuotesTabView?.selected = false
            self.dashboardTabView?.selected = true
            self.alertsTabView?.selected = false
            self.selectedIndex = 2
        }
        self.tabBar.addSubview(dashboardTabView!)
        
        xPostion += tabWidth
        
        alertsTabView = QITabView(frame: CGRect(x: xPostion, y: yPosition, width: tabWidth, height: tabHeight))
        alertsTabView?.title = "ALERTS"
        alertsTabView?.selected = false
        alertsTabView?.imageName = "tab_icon_alert"
        alertsTabView?.selectTab = { () in
            self.jobsTabView?.selected = false
            self.getQuotesTabView?.selected = false
            self.dashboardTabView?.selected = false
            self.alertsTabView?.selected = true
            self.selectedIndex = 3
        }
        self.tabBar.addSubview(alertsTabView!)
        
        xPostion += tabWidth
        
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
