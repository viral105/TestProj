//
//  AlertTableViewCell.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-17.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class AlertTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subTitleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var unreadIndicatorView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        unreadIndicatorView.layer.cornerRadius = unreadIndicatorView.frame.size.height/2.0;
        subTitleLabel.textColor = UIColor.QIGrayTextColor
        dateLabel.textColor = UIColor.QIGrayTextColor

    }
    
    func updateView(alertData: AlertData) {
        if let alertTitle = alertData.alertTitle {
            titleLabel.text = alertTitle
        }
        
        if let alertType = alertData.alertType {
            subTitleLabel.text = alertType
        }
        
        if let alertDateToDisplay = alertData.alertDateToDisplay {
            dateLabel.text = alertDateToDisplay
        }
        
        let fontSize: CGFloat = 16
        if let isRead = alertData.isRead, isRead == false {
            unreadIndicatorView.isHidden = false
            titleLabel.font = UIFont.fontWithWeight(weight: .heavy, size: fontSize)
        } else {
            unreadIndicatorView.isHidden = true
            titleLabel.font = UIFont.fontWithWeight(weight: .regular, size: fontSize)
        }
        
    }

}
