//
//  MediaViewModel.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

class MediaViewModel: Mappable {
    
    var id: Int?
    var url:String?
    var mediaType: MediaTypes?
    var title:String?
    var description:String?
    
    required init(map: Mapper) throws {
        try id = map.from("id")
        url = map.optionalFrom("url")
        mediaType = map.optionalFrom("mediaType")
        title = map.optionalFrom("title")
        description = map.optionalFrom("description")

    }
}
