//
//  QISingleServiceSelectionView.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-24.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class QISingleServiceSelectionView: UIView {

    @IBOutlet weak var indexLabel: UILabel!
    @IBOutlet weak var valueLabel: UILabel!
    
    @IBInspectable var indexString: String = "1" {
        didSet {
            indexLabel.text = indexString
        }
    }
    
    var contentView: UIView?
    
    var selectedCategory : CategoryData? = nil {
        didSet {
            if let selectedCategory = selectedCategory {
                valueLabel.text = selectedCategory.name!
            } else {
                valueLabel.text = "Select Service"
            }
        }
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        contentView = setup()
        indexLabel.layer.cornerRadius = indexLabel.frame.size.height/2.0
        indexLabel.clipsToBounds = true
        
        let superView = valueLabel.superview;
        superView?.layer.borderWidth = 1.0;
        superView?.layer.borderColor = UIColor.graySeperatorColor.cgColor
    }
    
    @IBAction func didPressSelectValueButton(_ sender: Any) {
        let parentView = self.superview?.superview?.superview?.superview
        parentView?.endEditing(true)
        let serviceTypePickerView = QIServiceTypePickerView.showToView(view: parentView, selectedData: selectedCategory)
        serviceTypePickerView.didSelectServiceType = {(categoryData) in
            self.selectedCategory = categoryData
        }
    }

}
