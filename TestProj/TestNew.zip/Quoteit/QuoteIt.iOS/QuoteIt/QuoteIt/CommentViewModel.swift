//
//  CommentViewModel.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

class CommentViewModel: Mappable {
    var commentID: Int?
    var posterId: String?
    var commentedBy: UserProfileViewModel?
    var commentDetail: String?
    var dateCommented: Date = Date()
    var approved: Bool = true
    var parentId: Int?
    var replies: [ReplyViewModel] = []
    var jobId: Int?
    var userId: Int?
    var quoteMessageImage: String?
    var quoteId: String?
    
    
    required init(map: Mapper) throws {
        try commentID = map.from("commentID")
        posterId = map.optionalFrom("posterId")
        commentedBy = map.optionalFrom("commentedBy")
        commentDetail = map.optionalFrom("commentDetail")
        dateCommented = map.parseDate("dateCommented")
        let approvedOptional: Bool? = map.optionalFrom("approved")
        if let approvedOptional = approvedOptional {
            approved = approvedOptional
        }
        let repliesOptional: [ReplyViewModel]? = map.optionalFrom("replies")
        if let repliesOptional = repliesOptional {
            self.replies = repliesOptional
        }
        parentId = map.optionalFrom("parentId")
        jobId = map.optionalFrom("jobId")
        userId = map.optionalFrom("userId")
        quoteMessageImage = map.optionalFrom("quoteMessageImage")
        quoteId = map.optionalFrom("quoteId")
        commentedBy = map.optionalFrom("")
        
    }
    
}
