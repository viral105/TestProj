//
//  GetQuotesStep2ViewController.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-11.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class GetQuotesStep2ViewController: UIViewController {

    @IBOutlet weak var selectLocationLabel: UILabel!
    @IBOutlet weak var selectCategoryLabel: UILabel!
    @IBOutlet weak var selectDateLabel: UILabel!
    
    var selectedCategory: CategoryData? = nil {
        didSet {
            if let selectedCategory = selectedCategory {
                selectCategoryLabel.text = selectedCategory.name!
            }
        }
    }
    var selectedLocation: AddressData? = nil {
        didSet {
            if let selectedLocation = selectedLocation {
                selectLocationLabel.text = selectedLocation.city
            }
        }
    }
    
    var selectedDate: Date? = nil {
        didSet {
            if let selectedDate = selectedDate {
                selectDateLabel.text = selectedDate.getFullDate()
            }
        }
    }
    static func initFromStoryBoard() -> GetQuotesStep2ViewController {
        return UIStoryboard(name: LOGGED_IN_USER_STORY_BORAD, bundle: nil).instantiateViewController(withIdentifier: "GetQuotesStep2ViewController") as! GetQuotesStep2ViewController
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "GET QUOTES"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK:- Button Press Events
    @IBAction func didPressSelectLocationButton(_ sender: Any) {
        let serviceTypePickerView = QIServiceTypePickerView.showToView(view: self.tabBarController?.view, selectedData: selectedLocation, pickerType: .city)
        serviceTypePickerView.didSelectCity = {(locationData) in
            self.selectedLocation = locationData
        }
    }
    
    @IBAction func didPressSelectCategoryButton(_ sender: Any) {
        let serviceTypePickerView = QIServiceTypePickerView.showToView(view: self.tabBarController?.view, selectedData: selectedCategory)
        serviceTypePickerView.didSelectServiceType = {(categoryData) in
            self.selectedCategory = categoryData
        }
    }
    
    @IBAction func didPressSelectDateButton(_ sender: Any) {
        let datePickerView = QIDatePickerView.showToView(view: self.tabBarController?.view)
        datePickerView.didSelectDate = {(selectedDate) in
            self.selectedDate = selectedDate
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
