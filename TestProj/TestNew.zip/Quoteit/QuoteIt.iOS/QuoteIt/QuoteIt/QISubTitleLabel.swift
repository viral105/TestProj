//
//  QISubTitleLabel.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-05.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class QISubTitleLabel: UILabel {

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder);
        self.textColor = UIColor.QIGrayTextColor
        self.font = UIFont.subTitleFont
    }

}
