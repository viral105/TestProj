//
//  JobDetailViewController.swift
//  QuoteIt
//
//  Created by Viral Narshana on 9/28/17.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class JobDetailViewController: UIViewController {

    @IBOutlet weak var jobDetailTableView: UITableView!
    @IBOutlet weak var jobDetailActivityIndicatorView: UIActivityIndicatorView!
    
    let refreshController = UIRefreshControl()
    var selectedFeed: JobsFeedViewModel!
    var selectedJobViewModel: JobViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Job Details"
        // Do any additional setup after loading the view.
        
        self.automaticallyAdjustsScrollViewInsets = false
        print(selectedFeed.quotes.count)
        
        
        JobsService.getJobDetail(jobId: selectedFeed.jobID!) { (jobViewModel, error) in
            if let error = error {
                self.showSlidingErrorMessage(errorString: error.message)
            } else {
                print("jobViewModel \(String(describing: jobViewModel?.comments[0].commentDetail))")
                self.selectedJobViewModel = jobViewModel
                self.jobDetailTableView.reloadData()
            }
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        

    }
 

}
extension JobDetailViewController: UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        if self.selectedJobViewModel != nil {
            return self.selectedJobViewModel.comments.count+1
        }
        else{
            return 1
        }
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat{
        return 600
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
//        return 336
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "JobCell", for: indexPath) as! JobCell
            
            cell.dispalyJobDetail(job: selectedFeed)
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "JobCommentCell", for: indexPath) as! JobDetailCommentCell
            
            cell.dispalyComment(comment: self.selectedJobViewModel.comments[indexPath.section-1])
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let jobViewModel = jobsArray[indexPath.row]
        //        JobsService.getJobDetail(jobId: jobViewModel.jobID!) { (jobViewModel, error) in
        //
        //        }
    }
}
