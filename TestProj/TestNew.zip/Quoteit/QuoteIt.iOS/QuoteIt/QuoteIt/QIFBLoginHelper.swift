//
//  FBLoginHelper.swift
//  QuoteIt
//
//  Created by Kuntal on 2017-06-27.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit
import FBSDKLoginKit

class QIFBLoginHelper: NSObject {
	
	class func loginWithFaceBook(
			forViewController viewController: UIViewController,
									complete: @escaping (_ emailAddress: String?, _ result: AnyObject?, _ error: Bool) -> Void) {
		if (FBSDKAccessToken.current() != nil) {
			QIFBLoginHelper.fetchUserInfo({ (emailAddress: String?, result: AnyObject?, error: Bool) in
				complete(emailAddress, result, error)
			})
		}
		else {
			var loginPermissions: [String] = []
			loginPermissions.append("email")
			FBSDKLoginManager().logIn(withReadPermissions: loginPermissions, from: viewController, handler: { (result:FBSDKLoginManagerLoginResult?, error: Error?) in
				if (error != nil) {
					complete(nil,nil,true)
				}
				else if result != nil {
					if result!.isCancelled {
						complete(nil,nil,true)
					}
					else if result!.grantedPermissions.contains("email") {
						QIFBLoginHelper.fetchUserInfo({ (emailAddress: String?, result: AnyObject?, error: Bool) in
							complete(emailAddress, result, error)
						})
					}
				}
				else {
					complete(nil,nil,true)
				}
			})
		}
	}
	
	
	class func fetchUserInfo(_ complete: @escaping (_ emailAddress: String?, _ result: AnyObject?, _ error: Bool) -> Void) {
		
		if let _ = FBSDKAccessToken.current() {
			let graphRequest: FBSDKGraphRequest = FBSDKGraphRequest(graphPath: "me", parameters: ["fields" : "id, name, first_name, last_name, picture.type(large), email"])
			graphRequest.start(completionHandler: { (connection: FBSDKGraphRequestConnection?, result: Any?, error: Error?) in
				if(error != nil) {
					complete(nil, nil, true)
				}
				else {
                    
                    
					if let data:[String:AnyObject] = result as? [String : AnyObject] {
						complete(data["email"] as? String, (result as AnyObject), false)
					}
				}
			})
		}
		
	}

}
