//
//  QuoteImagesViewController.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-09.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class QuoteImagesViewController: UIViewController {

    @IBOutlet weak var quoteImageView1: UIImageView!
    @IBOutlet weak var quoteImageView2: UIImageView!
    @IBOutlet weak var quoteImageView3: UIImageView!
    @IBOutlet weak var quoteImageView4: UIImageView!
    
    @IBOutlet weak var quoteImageView5: UIImageView!
    @IBOutlet weak var quoteImageView6: UIImageView!
    
    
    var imageSelectionData: ImageSelectionData!
    
    var currentButtonIndex = -1
    
    static func initFromStoryBoard() -> QuoteImagesViewController {
        return UIStoryboard(name: LOGGED_IN_USER_STORY_BORAD, bundle: nil).instantiateViewController(withIdentifier: "QuoteImagesViewController") as! QuoteImagesViewController
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Select Images"
        self.setupImages()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func didPressSelectImageButton(sender: UIButton) {
        currentButtonIndex = sender.tag
        showImagePickerOption()
    }
    
    
    override func imagePickerDidSelectImage(chosenImage: UIImage) {
        let width = UIScreen.main.bounds.size.width
        let height = width * IMAGE_ASPECT_RATIO
        let imageCropViewController = QIImageCropViewController(frame: self.view.bounds, image: chosenImage, aspectWidth: width, aspectHeight: height)
        self.navigationController?.pushViewController(imageCropViewController, animated: true)
        imageCropViewController.didSelectImage = { (image) in
            print("Image Selected")
            if self.imageSelectionData.selectedImages.count > self.currentButtonIndex {
                self.imageSelectionData.selectedImages[self.currentButtonIndex] = image
            } else {
                self.imageSelectionData.selectedImages.append(image)
            }
            _ = self.navigationController?.popViewController(animated: true)
            self.setupImages()
        }
        
    }
    
    func setupImages() {
        let imageViewArray = [quoteImageView1, quoteImageView2, quoteImageView3, quoteImageView4, quoteImageView5, quoteImageView6]
        
        for i in 0 ..< imageSelectionData.selectedImages.count {
            imageViewArray[i]?.image = imageSelectionData.selectedImages[i]
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
