//
//  CompanySignup1Controller.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-22.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit
import MBProgressHUD

class CompanySignup1Controller: UIViewController, QISearchAddressDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var emailTitleLabel: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var emailTextFieldTopMargin: NSLayoutConstraint!
    
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var passwordTextFieldTopMargin: NSLayoutConstraint!
    
    @IBOutlet weak var confirmPasswordLabel: UILabel!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextFieldTopMargin: NSLayoutConstraint!
    
    @IBOutlet weak var companyNameLabel: UILabel!
    @IBOutlet weak var companyNameTextField: UITextField!
    @IBOutlet weak var companyNameTextFieldTopMargin: NSLayoutConstraint!
    
    
    @IBOutlet weak var useLowerCaseLabel: UILabel!
    @IBOutlet weak var useUpperCaseLabel: UILabel!
    @IBOutlet weak var useDegitLabel: UILabel!
    @IBOutlet weak var user8CharactersLabel: UILabel!
    
    @IBOutlet weak var userImageView: UIImageView!
    
    @IBOutlet weak var companyInfoTitleLabel: UILabel!
    @IBOutlet weak var companyNameTitleLabel: UILabel!
    @IBOutlet weak var firstSectionHeight: NSLayoutConstraint!
    
    @IBOutlet weak var facebookLoginButton: UIButton!
    @IBOutlet weak var googlePlusLoginButton: UIButton!
    
    @IBOutlet weak var selectLocationSectionView: QISectionView!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var currenLocationButton: CurrentLocationButton!
    
    @IBOutlet weak var scrollContentViewHeight: NSLayoutConstraint!
    @IBOutlet weak var scrollViewBottomSpace: NSLayoutConstraint!
    
    
    var EMPTY_TEXT_FILED_TOP_MARGIN : CGFloat = 10
    var NON_EMPTY_TEXT_FILED_TOP_MARGIN : CGFloat = 15
    
    var isNotForCompany = false
    var selectedCity: AddressData? = nil
    
    var latitute: Double = 0.0
    var longitute: Double = 0.0
    
    static func initFromStoryBoard() -> CompanySignup1Controller {
        return UIStoryboard(name: MAIN_STORY_BORAD, bundle: nil).instantiateViewController(withIdentifier: "CompanySignup1Controller") as! CompanySignup1Controller
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "SIGN UP"
        
        layoutLabels()
        updatePasswordHelpLabels()
        NotificationCenter.default.addObserver(self, selector: #selector(CompanySignup1Controller.textFieldTextChanged(notification:)), name: NSNotification.Name.UITextFieldTextDidChange, object: nil)
        
        setDismissButton()
        
        currenLocationButton.didSelectLocation = { (address, latitute, longitute) in
            self.locationLabel.text = address
            self.latitute = latitute
            self.longitute = longitute
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(CompanySignup1Controller.keyboardDidChangeFrame(notification:)), name: NSNotification.Name.UIKeyboardDidChangeFrame, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
    }
    
    // MARK:- Notification Methods
    func keyboardDidChangeFrame(notification: Notification) {
        if let keyboardFrame = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            
            if keyboardFrame.origin.y >= UIScreen.main.bounds.size.height {
               hideKeyBoard()
            } else {
                showKeyBoard(keyboardHeight: keyboardFrame.size.height)
            }
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func layoutLabels() {
        setTextFieldMargins(editing: false, textField: emailTextField)
        setTextFieldMargins(editing: false, textField: passwordTextField)
        setTextFieldMargins(editing: false, textField: confirmPasswordTextField)
        setTextFieldMargins(editing: false, textField: companyNameTextField)
        
        emailTitleLabel.textColor = UIColor.QIGrayTextColor
        passwordLabel.textColor = UIColor.QIGrayTextColor
        confirmPasswordLabel.textColor = UIColor.QIGrayTextColor
        companyNameLabel.textColor = UIColor.QIGrayTextColor
        
        userImageView.layer.cornerRadius = userImageView.frame.size.height/2.0
        userImageView.clipsToBounds = true
        userImageView.backgroundColor = UIColor.graySeperatorColor
        
        if isNotForCompany {
            facebookLoginButton.isHidden = false
            googlePlusLoginButton.isHidden = false
            firstSectionHeight.constant = 140
            selectLocationSectionView.isHidden = false
            companyNameTitleLabel.text = "Username"
            companyNameTextField.placeholder = "Enter Username"
            companyInfoTitleLabel.isHidden = true
            continueButton.setTitle("SIGN UP", for: UIControlState.normal)
            continueButton.backgroundColor = UIColor.QIPinkColor
        } else {
            facebookLoginButton.isHidden = true
            googlePlusLoginButton.isHidden = true
            firstSectionHeight.constant = 50
            selectLocationSectionView.isHidden = true
            companyInfoTitleLabel.isHidden = false
        }
        
    }
    
    // MARK:- Button Press Events
    
    @IBAction func didPressContinueButton(_ sender: Any) {
        let emailAddressString = emailTextField.getText()
        let passwordString = passwordTextField.getText()
        let confirmPasswordString = confirmPasswordTextField.getText()
        let companyNameString = companyNameTextField.getText()
        
        if emailAddressString.length == 0 {
            showSlidingErrorMessage(errorString: ERROR_ENTER_EMAIL_ADDRESS)
            return
        }
        
        if !emailAddressString.isValidEmail() {
            showSlidingErrorMessage(errorString: ERROR_VALID_EMAIL_ADDRESS)
            return
        }
        
        if passwordString.length < 8 {
            showSlidingErrorMessage(errorString: ERROR_PASSWORD_IS_NOT_8_CHARACTERS_LONG)
            return
        }
        
        if !passwordString.hasLowerCase() {
            showSlidingErrorMessage(errorString: ERROR_PASSWORD_NOT_HAVE_LOWERCASE)
            return
        }
        
        if !passwordString.hasUpperCase() {
            showSlidingErrorMessage(errorString: ERROR_PASSWORD_NOT_HAVE_UPPERCASE)
            return
        }
        
        if !passwordString.hasDegit() {
            showSlidingErrorMessage(errorString: ERROR_PASSWORD_NOT_HAVE_DEGIT)
            return
        }
        
        
        if passwordString != confirmPasswordString {
            showSlidingErrorMessage(errorString: ERROR_PASSWORD_CONFIRM_PASSWORD_NOT_MATCHED)
            return
        }
        
        if companyNameString.length == 0 {
            showSlidingErrorMessage(errorString: ERROR_ENTER_COMPANY_NAME)
            return
        }
        
        
        if isNotForCompany {
            if (latitute == 0.0 && longitute == 0.0) {
                self.showSlidingErrorMessage(errorString: "Please select location")
                return
            }
            let user = UserModel()
            user.AccountType = .user
            user.Lat = latitute
            user.Lng = longitute
            user.Address = locationLabel.text
            user.DisplayName = companyNameString
            user.Email = emailAddressString
            user.Password = passwordString
            SignupRequest.user = user
            MBProgressHUD.showAdded(to: self.view, animated: false)
            UserService.createUser(user: user, completion: { (accessToken, error) in
                MBProgressHUD.hide(for: self.view, animated: false)
                if let accessToken = accessToken {
                    if let emailConfirmed = accessToken.emailConfirmed, emailConfirmed == true {
                        self.loginUser(accessToken: accessToken)
                    } else {
                        Global.accessToken = accessToken
                        let verifyEmailViewController = VerifyEmailViewController.initFromStoryBoard()
                        self.navigationController?.pushViewController(verifyEmailViewController, animated: true)
                    }
                } else {
                    self.showSlidingErrorMessage(errorString: error!.message)
                }
            })
            
        } else {
            let user = UserModel()
            user.AccountType = .business
            user.DisplayName = companyNameString
            user.Email = emailAddressString
            user.Password = passwordString
            SignupRequest.user = user
            // continue
            let companySignup2Controller = CompanySignup2Controller.initFromStoryBoard()
            self.navigationController?.pushViewController(companySignup2Controller, animated: true)
        }
        
        
        
    }
    @IBAction func didPressImageButton(_ sender: Any) {
        showImagePickerOption()
    }
    
    @IBAction func didPressSelectLocationButton(_ sender: Any) {
        
        let searchAddress = QISearchAddress(frame: self.view.bounds)
        searchAddress.delegate = self
        self.view.addSubview(searchAddress)
        
        /*let picker = QIServiceTypePickerView.showToView(view: self.navigationController?.view, selectedData: selectedCity, pickerType: QIServiceTypePickerView.QIPickerType.city)
        self.view.endEditing(true)
        self.perform(#selector(CompanySignup1Controller.showKeyBoard(keyboardHeight:)), with: QIServiceTypePickerView.PICKER_VIEW_HEIGHT, afterDelay: 1.0)
        //showKeyBoard(keyboardHeight: QIServiceTypePickerView.PICKER_VIEW_HEIGHT)
        picker.didSelectCity = {(addressData) in
            self.selectedCity = addressData
            self.locationLabel.text = addressData.city!
            self.hideKeyBoard()
        }*/
        
    }
    
    // MARK:- Search Address Delegate
    func didSelectLocation(name: String, latitute: Double, longitute: Double) {
        locationLabel.text = name
        self.latitute = latitute
        self.longitute = longitute
    }
    
    // MARK:- setScrollViewHeight
    func showKeyBoard(keyboardHeight: CGFloat) {
        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        if keyboardHeight == 0 {
            contentInset.bottom =  QIServiceTypePickerView.PICKER_VIEW_HEIGHT
        } else {
            contentInset.bottom = keyboardHeight
        }
        self.scrollView.contentInset = contentInset
        
    }
    
    func hideKeyBoard() {
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        self.scrollView.contentInset = contentInset
    }
        
    // MARK:- UIImagePickerControllerDelegate Methods
    override func imagePickerDidSelectImage(chosenImage: UIImage) {
        userImageView.contentMode = .scaleAspectFit
        userImageView.image = chosenImage
        
    }
    
    // MARK:- UITextFieldDelegate
    public func textFieldDidBeginEditing(_ textField: UITextField) {
        setTextFieldMargins(editing: true, textField: textField)
    }
    
    public func textFieldDidEndEditing(_ textField: UITextField) {
        setTextFieldMargins(editing: false, textField: textField)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldTextChanged(notification: Notification) {
        if let textField = notification.object as? UITextField, textField == passwordTextField {
            updatePasswordHelpLabels()
        }
    }
    
    func updatePasswordHelpLabels() {
        if let passwordString = passwordTextField.text {
            if passwordString.hasLowerCase() {
                useLowerCaseLabel.textColor = UIColor.QIPinkColor
            } else {
                useLowerCaseLabel.textColor = UIColor.QIGrayTextColor
            }
            
            if passwordString.hasUpperCase() {
                useUpperCaseLabel.textColor = UIColor.QIPinkColor
            } else {
                useUpperCaseLabel.textColor = UIColor.QIGrayTextColor
            }
            
            if passwordString.hasDegit() {
                useDegitLabel.textColor = UIColor.QIPinkColor
            } else {
                useDegitLabel.textColor = UIColor.QIGrayTextColor
            }
            
            if passwordString.length >= 8 {
                user8CharactersLabel.textColor = UIColor.QIPinkColor
            } else {
                user8CharactersLabel.textColor = UIColor.QIGrayTextColor
            }
        }
    }
    
    func setTextFieldMargins(editing: Bool, textField: UITextField) {
        var labelToShowHide: UILabel? = nil
        var constraint: NSLayoutConstraint? = nil
        if textField == emailTextField {
            labelToShowHide = emailTitleLabel
            constraint = emailTextFieldTopMargin
        } else if textField == passwordTextField {
            labelToShowHide = passwordLabel
            constraint = passwordTextFieldTopMargin
        } else if textField == confirmPasswordTextField {
            labelToShowHide = confirmPasswordLabel
            constraint = confirmPasswordTextFieldTopMargin
        } else {
            labelToShowHide = companyNameLabel
            constraint = companyNameTextFieldTopMargin
        }
        var shouldHideLabel = true;
        if editing {
            shouldHideLabel = false
        } else {
            if let length = textField.text?.length, length > 0 {
                shouldHideLabel = false
            } 
        }
        
        if shouldHideLabel {
            labelToShowHide?.isHidden = true
            constraint?.constant = EMPTY_TEXT_FILED_TOP_MARGIN
        } else {
            labelToShowHide?.isHidden = false
            constraint?.constant = NON_EMPTY_TEXT_FILED_TOP_MARGIN
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
