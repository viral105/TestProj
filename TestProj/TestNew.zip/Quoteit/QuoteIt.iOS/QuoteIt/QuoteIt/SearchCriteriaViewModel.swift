//
//  SearchCriteriaViewModel.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-09-13.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import UIKit

class SearchCriteriaViewModel {
    var category: Int? = nil
    var categoryName: String? = nil
    var jobCity: Int? = nil
    var city: String? = nil
    var address: String? = nil
    var lat: Double? = nil
    var lng: Double? = nil
    var searchType: JobSearchType? = nil
    var sortBy: Int? = nil
    var page: Int? = nil
    var pageSize: Int? = nil
    var sortDirection = 0
    
    open func encodeToJSON() -> [String:Any?] {
        var nillableDictionary = [String:Any?]()
        nillableDictionary["Category"] = self.category
        nillableDictionary["CategoryName"] = self.categoryName
        nillableDictionary["JobCity"] = self.jobCity
        nillableDictionary["City"] = self.city
        nillableDictionary["address"] = self.address
        nillableDictionary["SortBy"] = self.sortBy
        nillableDictionary["Lat"] = self.lat
        nillableDictionary["lng"] = self.lng
        nillableDictionary["SearchType"] = self.searchType?.rawValue
        nillableDictionary["Page"] = self.page
        nillableDictionary["PageSize"] = self.pageSize
        nillableDictionary["SortDirection"] = self.sortDirection
        
        let dictionary: [String:Any] = rejectNil(nillableDictionary) ?? [:]
        return dictionary
    }
    
    func rejectNil(_ source: [String:Any?]) -> [String:Any]? {
        var destination = [String:Any]()
        for (key, nillableValue) in source {
            if let value: Any = nillableValue {
                destination[key] = value
            }
        }
        
        if destination.isEmpty {
            return nil
        }
        return destination
    }
}
