//
//  JobsViewController.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-28.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class JobsViewController: UIViewController {

    var jobsTableViewController: JobsTableViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "QUOTE IT"
        setMenuButton()
        loadJobs()
    }

    func loadJobs() {
        JobsService.loadJobs { (jobs, error) in
            if let error = error {
                self.showSlidingErrorMessage(errorString: error.message)
            } else {
                self.jobsTableViewController?.jobsArray = jobs
                self.jobsTableViewController?.tableView.reloadData()
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "setJobTableView" {
            jobsTableViewController = segue.destination as? JobsTableViewController
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
