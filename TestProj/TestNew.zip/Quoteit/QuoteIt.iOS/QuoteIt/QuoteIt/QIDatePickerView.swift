//
//  DatePickerView.swift
//  parkatech
//
//  Created by Kuntal on 2017-06-24
//  Copyright © 2016 Weisetech Developers. All rights reserved.
//

import UIKit

class QIDatePickerView: UIView {

    
    static var DATE_PICKER_VIEW_HEIGHT: CGFloat = 260
    static var DATE_PICKER_VIEW_ANIMATION_DURATION: CGFloat = 0.25
    
    
    @IBOutlet weak var parkaDatePicker: UIDatePicker!
    
    var contentView: UIView!
    
    var didSelectDate: ((_ date: Date) -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView = setup()
        
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.25
        self.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.layer.shadowRadius = 3
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        contentView = setup()
    }


    @IBAction func didPressDatePickerDoneButton(_ sender: Any) {
        if let didSelectDate = didSelectDate {
            didSelectDate(parkaDatePicker.date)
        }
        removeView()
    }
    
    
    static func showToView(view: UIView?) -> QIDatePickerView {
        let datePickerView = QIDatePickerView(frame: CGRect(x: 0, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width, height: DATE_PICKER_VIEW_HEIGHT))
        if let view = view {
            view.addSubview(datePickerView)
        }
        
        
        UIView.animate(withDuration: TimeInterval(DATE_PICKER_VIEW_ANIMATION_DURATION), animations: {
            datePickerView.frame = CGRect(x: 0, y: UIScreen.main.bounds.size.height - DATE_PICKER_VIEW_HEIGHT, width: UIScreen.main.bounds.size.width, height: DATE_PICKER_VIEW_HEIGHT)
            
        })
        
        return datePickerView
    }
    
    
    func removeView() {
        UIView.animate(withDuration: TimeInterval(QIDatePickerView.DATE_PICKER_VIEW_ANIMATION_DURATION), animations: {
            self.frame = CGRect(x: 0, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width, height: QIDatePickerView.DATE_PICKER_VIEW_HEIGHT)
            self.perform(#selector(QIDatePickerView.removeFromSuperview), with: nil, afterDelay: TimeInterval(QIDatePickerView.DATE_PICKER_VIEW_ANIMATION_DURATION))
            
        })

    }
}


