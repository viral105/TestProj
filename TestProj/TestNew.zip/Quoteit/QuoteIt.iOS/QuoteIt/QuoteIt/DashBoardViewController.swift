//
//  DashBoardViewController.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-28.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class DashBoardViewController: UIViewController {

    @IBOutlet var conBottomViewWidthMyJob: NSLayoutConstraint!
    @IBOutlet var conBottomViewWidthHis: NSLayoutConstraint!
    @IBOutlet var conBottomViewWidthFav: NSLayoutConstraint!
    @IBOutlet var conBottomViewLeadingHistory: NSLayoutConstraint!
    @IBOutlet var conBottomViewLeadingMyJobs: NSLayoutConstraint!
    @IBOutlet var conBottomViewLeadingFavorities: NSLayoutConstraint!
    @IBOutlet var viewContainingSeg: UIView!
    let colorSegSelected = UIColor(colorLiteralRed: 225/255.0, green: 70/255.0, blue: 104/255.0, alpha: 1)
    let colorSegFontUnSelect = UIColor(colorLiteralRed: 141/255.0, green: 141/255.0, blue: 141/255.0, alpha: 1)
    var objVC: DashboardPageVC!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "DASHBOARD"
        setMenuButton()
        let notificationName = Notification.Name("NotifId")
        
        // Register to receive notification
        NotificationCenter.default.addObserver(self, selector: #selector(self.changeSeg), name: notificationName, object: nil)
        
        
        objVC = (self.storyboard?.instantiateViewController(withIdentifier: "DashboardPageVC"))! as! DashboardPageVC
        
        self.addChildViewController(objVC)
        objVC.view.frame = CGRect(x: 0, y: 146, width: self.view.frame.size.width, height: self.view.frame.size.height-146)
        self.view.addSubview(objVC.view)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        print("viewWillAppear")
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func btnSegment_Tapped(sender: UIButton){
        switch sender.tag {
        case 101:
            let objHisBtn = viewContainingSeg.viewWithTag(102) as! UIButton
            let objFavBtn = viewContainingSeg.viewWithTag(103) as! UIButton
            sender.backgroundColor = colorSegSelected
            objHisBtn.backgroundColor = UIColor.clear
            objFavBtn.backgroundColor = UIColor.clear
            sender.setTitleColor(UIColor.white, for: UIControlState.normal)
            objHisBtn.setTitleColor(colorSegFontUnSelect, for: UIControlState.normal)
            objFavBtn.setTitleColor(colorSegFontUnSelect, for: UIControlState.normal)
            conBottomViewLeadingMyJobs.priority = 750
            conBottomViewLeadingHistory.priority = 250
            conBottomViewLeadingFavorities.priority = 250
            conBottomViewWidthMyJob.priority = 750
            conBottomViewWidthHis.priority = 250
            conBottomViewWidthFav.priority = 250
            objVC.setViewControllers([objVC.orderedViewControllers[0]], direction: .forward, animated: true, completion: nil)
        case 102:
            let objMyJobBtn = viewContainingSeg.viewWithTag(101) as! UIButton
            let objFavBtn = viewContainingSeg.viewWithTag(103) as! UIButton
            sender.backgroundColor = colorSegSelected
            objMyJobBtn.backgroundColor = UIColor.clear
            objFavBtn.backgroundColor = UIColor.clear
            sender.setTitleColor(UIColor.white, for: UIControlState.normal)
            objMyJobBtn.setTitleColor(colorSegFontUnSelect, for: UIControlState.normal)
            objFavBtn.setTitleColor(colorSegFontUnSelect, for: UIControlState.normal)
            conBottomViewLeadingMyJobs.priority = 250
            conBottomViewLeadingHistory.priority = 750
            conBottomViewLeadingFavorities.priority = 250
            conBottomViewWidthMyJob.priority = 250
            conBottomViewWidthHis.priority = 750
            conBottomViewWidthFav.priority = 250
            objVC.setViewControllers([objVC.orderedViewControllers[1]], direction: .forward, animated: true, completion: nil)
        case 103:
            let objMyJobBtn = viewContainingSeg.viewWithTag(101) as! UIButton
            let objHisBtn = viewContainingSeg.viewWithTag(102) as! UIButton
            sender.backgroundColor = colorSegSelected
            objMyJobBtn.backgroundColor = UIColor.clear
            objHisBtn.backgroundColor = UIColor.clear
            sender.setTitleColor(UIColor.white, for: UIControlState.normal)
            objMyJobBtn.setTitleColor(colorSegFontUnSelect, for: UIControlState.normal)
            objHisBtn.setTitleColor(colorSegFontUnSelect, for: UIControlState.normal)
            conBottomViewLeadingMyJobs.priority = 250
            conBottomViewLeadingHistory.priority = 250
            conBottomViewLeadingFavorities.priority = 750
            conBottomViewWidthMyJob.priority = 250
            conBottomViewWidthHis.priority = 250
            conBottomViewWidthFav.priority = 750
            objVC.setViewControllers([objVC.orderedViewControllers[2]], direction: .forward, animated: true, completion: nil)
        default:
            print("");
        }
        
        viewContainingSeg.setNeedsDisplay()
        viewContainingSeg.layoutIfNeeded()
    }
    func changeSeg(notif: NSNotification) {
        print(notif.userInfo?["strInd"]! ?? "default")
    }
}
extension DashboardPageVCDelegate {
    func changeSeg(ind: Int) {
        print(ind)
    }
}
