//
//  QIString.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-19.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import UIKit

extension String {
    var length: Int {
        get {
            return self.characters.count
        }
    }
    
    func hasLowerCase() -> Bool {
        let lowerCase = CharacterSet.lowercaseLetters
        
        let range = self.rangeOfCharacter(from: lowerCase)
        
        if range != nil {
            return true
        }
        return false
    }
    
    func hasUpperCase() -> Bool {
        
        let upperCase = CharacterSet.uppercaseLetters
        let range = self.rangeOfCharacter(from: upperCase)
        
        if range != nil {
            return true
        }
        return false
    }
    
    func hasDegit() -> Bool {
        let decimalCharacters = CharacterSet.decimalDigits
        
        let decimalRange = self.rangeOfCharacter(from: decimalCharacters)
        
        if decimalRange != nil {
            return true
        }
        return false
    }
    
    func isValidEmail() -> Bool {
        // print("validate calendar: \(testStr)")
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: self)
    }
    
}
