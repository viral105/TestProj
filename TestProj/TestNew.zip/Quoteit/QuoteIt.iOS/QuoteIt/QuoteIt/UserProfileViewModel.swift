//
//  UserProfileViewModel.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

class UserProfileViewModel: Mappable {
    
    var email: String?
    var displayName: String?
    var city: Int?
    var cityName: String?
    var avatar: String?
    var counter: Int?
    var rating: Double?
    var phoneNumber: String?
    var accountType: AccountType?
    var memberSince: String?
    var id: String?
    var emailConfirmed: Bool?
    
    
    required init(map: Mapper) throws {
        try email = map.from("email")
        displayName = map.optionalFrom("displayName")
        city = map.optionalFrom("city")
        cityName = map.optionalFrom("cityName")
        avatar = map.optionalFrom("avatar")
        counter = map.optionalFrom("counter")
        phoneNumber = map.optionalFrom("phoneNumber")
        accountType = map.optionalFrom("accountType")
        memberSince = map.optionalFrom("memberSince")
        id = map.optionalFrom("id")
        emailConfirmed = map.optionalFrom("emailConfirmed")
    }
    
    init() {
        
    }
}
