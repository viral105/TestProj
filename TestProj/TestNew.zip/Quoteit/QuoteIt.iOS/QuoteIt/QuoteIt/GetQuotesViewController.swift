//
//  GetQuotesViewController.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-28.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit
import KMPlaceholderTextView


class GetQuotesViewController: UIViewController {

    @IBOutlet weak var jobTitleTextField: UITextField!
    
    @IBOutlet weak var jobDescriptionTextView: KMPlaceholderTextView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var imageScrollViewSuperView: QISectionView!
    @IBOutlet weak var imageScrollView: UIScrollView!
    @IBOutlet weak var imageScrollContentView: UIView!
    @IBOutlet weak var imageScrollContentWidth: NSLayoutConstraint!
    
    var imageSelectionData = ImageSelectionData()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "GET QUOTES"
        jobDescriptionTextView.addDoneToolBar()
        setMenuButton()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(didPressSelectImageButton))
        imageScrollView.addGestureRecognizer(tapGesture)
    }

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(CompanySignup1Controller.keyboardDidChangeFrame(notification:)), name: NSNotification.Name.UIKeyboardDidChangeFrame, object: nil)
        setupImageScrollView()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardDidChangeFrame, object: nil)
    }
    
    // MARK:- Setup ImageScrollView
    func setupImageScrollView() {
        
        var xPostion: CGFloat = 0;
        let width = appDelegate.window?.bounds.width
        
        for i in 0 ..< imageSelectionData.selectedImages.count {
            let rect = CGRect(x: xPostion, y: 0.0, width: width!, height: imageScrollContentView.bounds.size.height)
            let imageView = UIImageView(frame: rect)
            imageView.image = imageSelectionData.selectedImages[i]
            imageScrollContentView.addSubview(imageView)
            xPostion += width!
        }
        
        imageScrollContentWidth.constant = xPostion;
    }
    
    // MARK:- Button press events
    func didPressSelectImageButton() {
        let quoteImagesViewController = QuoteImagesViewController.initFromStoryBoard()
        quoteImagesViewController.imageSelectionData = imageSelectionData
        self.navigationController?.pushViewController(quoteImagesViewController, animated: true)
    }
    
    @IBAction func didPressContinueButton(sender: UIButton) {
        let qetQuotesStep2ViewController = GetQuotesStep2ViewController.initFromStoryBoard()
        self.navigationController?.pushViewController(qetQuotesStep2ViewController, animated: true)
    }
    
    // MARK:- Notification Methods
    func keyboardDidChangeFrame(notification: Notification) {
        if let keyboardFrame = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            
            if keyboardFrame.origin.y >= UIScreen.main.bounds.size.height {
                hideKeyBoard()
            } else {
                showKeyBoard(keyboardHeight: keyboardFrame.size.height)
            }
            
        }
    }
    
    // MARK:- setScrollViewHeight
    func showKeyBoard(keyboardHeight: CGFloat) {
        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        if keyboardHeight == 0 {
            contentInset.bottom =  QIServiceTypePickerView.PICKER_VIEW_HEIGHT
        } else {
            contentInset.bottom = keyboardHeight - 49 - 50 // 49 tab bar height, 50 for button height
        }
        self.scrollView.contentInset = contentInset
        
    }
    
    func hideKeyBoard() {
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        self.scrollView.contentInset = contentInset
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
