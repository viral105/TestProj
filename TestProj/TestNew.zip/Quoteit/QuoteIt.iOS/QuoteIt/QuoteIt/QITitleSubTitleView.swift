//
//  QITitleSubTitleView.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-11.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

@IBDesignable

class QITitleSubTitleView: UIView {

    @IBOutlet weak var titleLabel: QITitleLabel!
    @IBOutlet weak var subTitleLabel: QISubTitleLabel!
    @IBOutlet weak var seperatorView: UIView!
    
    
    @IBInspectable var title: String = "" {
        didSet{
            titleLabel.text = title
        }
    }
    
    @IBInspectable var subTitle: String = "" {
        didSet{
            subTitleLabel.text = subTitle
        }
    }
    
    @IBInspectable var drawSectionLine: Bool = false {
        didSet {
            //seperatorView.isHidden = !drawSectionLine
        }
    }
    
    @IBInspectable var boderColor: UIColor = UIColor.graySeperatorColor {
        didSet {
            seperatorView.backgroundColor = boderColor
        }
    }
    
    var contentView: UIView?
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        contentView = setup()
        seperatorView.backgroundColor = UIColor.graySeperatorColor
    }
    
    
    

}
