//
//  UserService.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-17.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Alamofire

class UserService {
    
    static func createUser(user: UserModel, completion:@escaping (_ accessToken:AccessToken?, _ error:QIError?) -> Void) {
        let url = "\(BASE_URL)account/register"
        
        let perameters = user.encodeToJSON()
        
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = HTTPMethod.post.rawValue
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let pjson = Global.jsonToString(json: perameters as AnyObject)
        let data = (pjson?.data(using: .utf8))! as Data
        
        request.httpBody = data
        
        
        Alamofire.request(request).responseJSON { (response) in
            if let jsonResponse = response.result.value as? NSDictionary {
                if let error = QIError.parseFromJson(json: jsonResponse) {
                    completion(nil, error)
                } else {
                    let accessToken = AccessToken.from(jsonResponse)
                    completion(accessToken, nil)
                }
            } else {
                completion(nil, QIError.getError(message: "Error occurred while trying to sign up"))
            }
        }
        
    }
    
    static func verifyEmailCode(code: String, completion:@escaping (_ error:QIError?) -> Void) {
        
        let url = "\(BASE_URL)account/VerifyEmailCode"
        
        let perameters = ["id": code]
        Alamofire.request(url, method: HTTPMethod.get, parameters: perameters, headers: getHTTPHeaders()).responseJSON { (response) in
            print("response \(response.value)")
            if let jsonResponse = response.result.value as? NSDictionary {
                if let error = QIError.parseFromJson(json: jsonResponse) {
                    completion(error)
                } else {
                    completion(nil)
                }
            } else {
                completion(nil)
                //completion(QIError.getError(message: "Error occurred while trying to verify email"))
            }
        }
    }
    static func getAccessTokenForLocalUser(username: String, password: String, completion:@escaping (_ accessToken:AccessToken?, _ error:QIError?) -> Void) {
        
        let url = "\(BASE_URL)account/ObtainLocalAccessTokenForUser"
        let perameters = ["username": username, "password": password, "deviceId": ""]
        
        Alamofire.request(url, method: HTTPMethod.get, parameters: perameters).responseJSON { (response) in
            if let jsonResponse = response.result.value as? NSDictionary {
                if let error = QIError.parseFromJson(json: jsonResponse) {
                    completion(nil, error)
                } else {
                    let accessToken = AccessToken.from(jsonResponse)
                    completion(accessToken, nil)
                }
            } else {
                completion(nil, QIError.getError(message: "Error occurred while trying to login"))
            }
        }
        
    }
    
    static func getUserAlert(completion: @escaping (_ alerts: [AlertData],_ error: QIError?) -> Void) {
        print("\(BASE_URL)\(GET_KEY_WORD_LIST)")
        
        let url = "\(BASE_URL)\(GET_USER_ALERT_LIST)"
        
        Alamofire.request(url, method: HTTPMethod.get, parameters: nil, headers: getHTTPHeaders()).responseJSON { (response) in
            var alerts: [AlertData] = []
            if let jsonResponse = response.result.value as? NSDictionary {
                if let error = QIError.parseFromJson(json: jsonResponse) {
                    completion(alerts, error)
                }
            } else {
                if let alertJsonArray = response.result.value as? [NSDictionary] {
                    for alertDictionary in alertJsonArray {
                        let alertData = AlertData.from(alertDictionary)
                        alerts.append(alertData!)
                    }
                }
                completion(alerts, nil)
            }
        }
        
    }
    
    
    static func getHTTPHeaders() -> HTTPHeaders {
        let headers: HTTPHeaders = [
            "Authorization": "Bearer \(Global.accessToken!.token!)",
        ]
        
        return headers
    }
}
