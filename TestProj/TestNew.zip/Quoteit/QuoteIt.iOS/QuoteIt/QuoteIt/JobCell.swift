//
//  JobCell.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit
import Kingfisher

class JobCell: UITableViewCell {

    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var categoryLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var jobImageView: UIImageView!
    @IBOutlet weak var detailView: UIView!
    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var adidLabel: UILabel!
    @IBOutlet weak var deadlineButton: UIButton!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.selectionStyle = .none
        titleLabel.textColor = UIColor.black
        categoryLabel.textColor = UIColor.QIGrayTextColor
        locationLabel.textColor = UIColor.QIGrayTextColor
        titleLabel.font = UIFont.fontWithWeight(weight: .medium, size: 14)
        categoryLabel.font = UIFont.fontWithWeight(weight: .regular, size: 10)
        locationLabel.font = UIFont.fontWithWeight(weight: .regular, size: 10)
        
        jobImageView.contentMode = .scaleAspectFill
        jobImageView.clipsToBounds = true
        
        if detailView != nil {
            descLabel.font = UIFont.fontWithWeight(weight: .medium, size: 12)
            adidLabel.font = UIFont.fontWithWeight(weight: .medium, size: 12)
            deadlineButton.layer.borderColor = UIColor.QIPinkColor.cgColor
            deadlineButton.layer.borderWidth = 1.0
            deadlineButton.setTitleColor(UIColor.QIPinkColor, for: .normal)
        }
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func prepareForReuse() {
        userImageView.kf.cancelDownloadTask()
    }
    
    func dispalyJob(job: JobsFeedViewModel) {
        
        userImageView.roundImage()
        userImageView.downloadImage(urlString: job.posterAvatar)

        
        titleLabel.text = job.title
        let categoryStaticString = "Category: "
        if let category = job.category {
            categoryLabel.text = String(format: "%@ %@", categoryStaticString, category)
        } else {
            categoryLabel.text = String(format: "%@", categoryStaticString)
        }
        
        var locationString = ""
        if let jobCity = job.city {
            locationString = String(format: "%@ | ", jobCity)
        }
        
        
        //print("locationLabel \(job.startDate?.timeAgo)")
        if let startDate = job.startDate {
            locationLabel.text = String(format: "%@%@", locationString, startDate.timeAgo)
        }
        jobImageView.image = nil
        
        jobImageView.downloadImage(urlString: job.thumbnail)

        
        
    }

    func dispalyJobDetail(job: JobsFeedViewModel) {
        
        userImageView.roundImage()
        userImageView.downloadImage(urlString: job.posterAvatar)
        
        
        titleLabel.text = job.title
        let categoryStaticString = "Category: "
        if let category = job.category {
            categoryLabel.text = String(format: "%@ %@", categoryStaticString, category)
        } else {
            categoryLabel.text = String(format: "%@", categoryStaticString)
        }
        
        var locationString = ""
        if let jobCity = job.city {
            locationString = String(format: "%@ | ", jobCity)
        }
        
        
        //print("locationLabel \(job.startDate?.timeAgo)")
        if let startDate = job.startDate {
            locationLabel.text = String(format: "%@%@", locationString, startDate.timeAgo)
        }
        jobImageView.image = nil
        
        jobImageView.downloadImage(urlString: job.thumbnail)
        
        if let startDate = job.detail {
            descLabel.text = job.detail
        }
        
        
    }
}
