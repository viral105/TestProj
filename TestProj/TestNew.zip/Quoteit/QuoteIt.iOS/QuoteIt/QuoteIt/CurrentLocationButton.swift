//
//  CurrentLocationButton.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-08-03.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class CurrentLocationButton: UIButton {

    
    var didSelectLocation: ((_ name: String, _ latitute: Double, _ longitute: Double) -> Void)?
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        addTarget(self, action: #selector(didPressCurrentLocationButton), for: .touchUpInside)
        self.setImage(UIImage(named: "current_location"), for: .normal)
        QILocationManager.sharedLocationManager.didUpdateLocation = { (location) in
            if let currentLocation = location {
                self.searchAddress(location: currentLocation)
            } else {
                appDelegate.window?.rootViewController?.showSlidingErrorMessage(errorString: "An error occurred while trying to get your location")
            }
        }
    }
    
    
    func didPressCurrentLocationButton() {
        QILocationManager.sharedLocationManager.locateMe()
    }
    
    func searchAddress(location: CLLocation) {
        
        let span = MKCoordinateSpanMake(0.005, 0.005)
        let region = MKCoordinateRegionMake(location.coordinate, span)
        
        let request = MKLocalSearchRequest()
        request.region = region
        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(location) { (mapItems, error) in
            if let mapItems = mapItems {
                if mapItems.count > 0 {
                    self.didSelectLocation!(mapItems[0].parseAddress(), location.coordinate.latitude, location.coordinate.longitude)
                } else {
                    appDelegate.window?.rootViewController?.showSlidingErrorMessage(errorString: "An error occurred while trying to get your location")
                }
            }
            
        }

    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
