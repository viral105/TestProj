//
//  QIErrorMessages.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-22.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation

let ERROR_ENTER_EMAIL_ADDRESS = "Please enter email address"
let ERROR_VALID_EMAIL_ADDRESS = "Please enter valid email address"
let ERROR_PASSWORD_NOT_HAVE_LOWERCASE = "Password must have a lowercase"
let ERROR_PASSWORD_NOT_HAVE_UPPERCASE = "Password must have a uppercase"
let ERROR_PASSWORD_NOT_HAVE_DEGIT = "Password must have a degit"
let ERROR_PASSWORD_IS_NOT_8_CHARACTERS_LONG = "Password must be 8 characters longs"
let ERROR_PASSWORD_CONFIRM_PASSWORD_NOT_MATCHED = "Password and confirm password doesn't match"
let ERROR_ENTER_COMPANY_NAME = "Please enter company name"
let ERROR_ENTER_BUSINESS_ADDRESS = "Please enter business address"
let ERROR_SELECT_RADIUS = "Please select radius"
let ERROR_BUSINESS_CATEGORY = "Please select service offered";
