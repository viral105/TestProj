//
//  LeftMenuTableViewCell.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-18.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

enum LeftMenuFirstSectionCellType: Int {
    case profile = 0
    case notification = 1
    case reportProblem = 2
    case faq = 3
    
    func getTitle()-> String {
        switch self {
        case .profile:
            return "PROFILE"
        case .notification:
            return "NOTIFICATIONS"
        case .reportProblem:
            return "REPORT A PROBLEM"
        case .faq:
            return "FAQ"
        }
    }
    
    func getImageName()-> String {
        switch self {
        case .profile:
            return "left_menu_profile"
        case .notification:
            return "left_menu_notification"
        case .reportProblem:
            return "left_menu_report_problem"
        case .faq:
            return "left_menu_faq"
        }
    }
    
    
}

enum LeftMenuSecondSectionCellType: Int {
    case legal = 0
    case termsAndCondition = 1
    case appVersion = 2
    case rateThisApp = 3
    
    func getTitle()-> String {
        switch self {
        case .legal:
            return "LEGAL"
        case .termsAndCondition:
            return "TERMS & CONDITION"
        case .appVersion:
            return "APP VERSION"
        case .rateThisApp:
            return "RATE THIS APP"
        }
    }
    
    func getImageName()-> String {
        switch self {
        case .legal:
            return "left_menu_legal"
        case .termsAndCondition:
            return "left_menu_terms_and_condition"
        case .appVersion:
            return "left_menu_app_version"
        case .rateThisApp:
            return "left_menu_rate"
        }
    }
}


class LeftMenuTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var iconImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func updateView(title: String, imageName: String) {
        titleLabel.text = title
        iconImageView.tintColor = UIColor.QIDarkGraytColor
        iconImageView.image = UIImage(named: imageName)?.withRenderingMode(UIImageRenderingMode.alwaysTemplate)
    }

}
