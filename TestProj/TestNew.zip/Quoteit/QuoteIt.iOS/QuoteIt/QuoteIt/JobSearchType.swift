//
//  JobSortingType.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-09-13.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation

enum JobSearchType: String {
    case newestFirst = "NewestFirst"
    case quotes = "Quotes"
    case waiting = "Waiting"
    case dateProposed = "DateProposed"
    case appointments = "Appointments"
}
