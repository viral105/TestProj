//
//  QuoteViewModel.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

class QuoteViewModel: Mappable {
    
    var id: Int?
    var userId: String?
    var quotedBy: UserProfileViewModel?
    var notesBySubmitter: String?
    var dateModified: Date = Date()
    var dateSubmitted: Date = Date()
    var amount: Float?
    var exceptions: String?
    var warranty: String?
    var quoteType: Int?
    var statusID: Int?
    var comments: [CommentViewModel] = []
    var jobId: Int?
    var acceptedDate: Date = Date()
    
    required init(map: Mapper) throws {
        try id = map.from("id")
        userId = map.optionalFrom("userId")
        quotedBy = map.optionalFrom("quotedBy")
        notesBySubmitter = map.optionalFrom("notesBySubmitter")
        dateModified = map.parseDate("dateModified")
        dateSubmitted = map.parseDate("dateSubmitted")
        amount = map.optionalFrom("amount")
        exceptions = map.optionalFrom("exceptions")
        warranty = map.optionalFrom("warranty")
        quoteType = map.optionalFrom("quoteType")
        statusID = map.optionalFrom("statusID")
        
        let commentsOptional: [CommentViewModel]? = map.optionalFrom("comments")
        if let commentsOptional = commentsOptional {
            comments = commentsOptional
        }
        jobId = map.optionalFrom("jobId")
        acceptedDate = map.parseDate("acceptedDate")
        
    }
    
    
}
