//
//  JobDetailCommentCell.swift
//  QuoteIt
//
//  Created by Viral Narshana on 10/24/17.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class JobDetailCommentCell: UITableViewCell {

    @IBOutlet weak var commentView: UIView!
    @IBOutlet weak var commentDescLabel: UILabel!
    @IBOutlet weak var commentFromLabel: UILabel!
    @IBOutlet weak var commentUserImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        if commentView != nil {
            commentDescLabel.font = UIFont.fontWithWeight(weight: .medium, size: 12)
            commentFromLabel.font = UIFont.fontWithWeight(weight: .medium, size: 12)
            
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func dispalyComment(comment: CommentViewModel) {
        
        commentUserImageView.roundImage()
        commentUserImageView.downloadImage(urlString: comment.commentedBy?.avatar)
        
        
        commentDescLabel.text = comment.commentDetail
        commentFromLabel.text = comment.commentedBy?.displayName
/*
        if let startDate = job.startDate {
            locationLabel.text = String(format: "%@%@", locationString, startDate.timeAgo)
        }
        jobImageView.image = nil
        
        jobImageView.downloadImage(urlString: job.thumbnail)
*/        
        
        
    }
}
