//
//  AccessToken.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-17.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

class AccessToken:Mappable {
    
    var displayName: String?
    var userId: String?
    var email: String?
    var accountType: AccountType?
    var emailConfirmed: Bool? = false
    var token: String?
    var tokenType: String?
    var expireIn: Int?
    var expires: Date?
    var issued: Date?
    
    required init(map: Mapper) throws {
        try displayName = map.from("displayName")
        userId = map.optionalFrom("userId")
        email = map.optionalFrom("email")
        accountType = map.optionalFrom("accountType")
        emailConfirmed = map.optionalFrom("emailConfirmed")
        token = map.optionalFrom("token")
        tokenType = map.optionalFrom("tokenType")
        expireIn = map.optionalFrom("expireIn")
        //expires = map.optionalFrom("expires", transformation: nil)
        //issued = map.optionalFrom("issued", transformation: nil)
    }
}


