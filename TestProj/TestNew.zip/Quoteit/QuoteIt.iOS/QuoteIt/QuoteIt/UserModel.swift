//
//  UserModel.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-08-01.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation

class UserModel {
    var Email: String = ""
    var Password: String = ""
    var Avatar: String?
    var Address: String?
    var Lat: Double?
    var Lng: Double?
    var DisplayName:String = ""
    var AccountType: AccountType?
    var UserCategories: [Int] = []
    

    
    open func encodeToJSON() -> Any {
        var nillableDictionary = [String:Any?]()
        nillableDictionary["Email"] = self.Email
        nillableDictionary["Password"] = self.Password
        nillableDictionary["Avatar"] = self.Avatar
        nillableDictionary["Address"] = self.Address
        nillableDictionary["Lat"] = self.Lat
        nillableDictionary["Lng"] = self.Lng
        nillableDictionary["DisplayName"] = self.DisplayName
        nillableDictionary["AccountType"] = self.AccountType?.rawValue
        nillableDictionary["UserCategories"] = self.UserCategories
        
        let dictionary: [String:Any] = rejectNil(nillableDictionary) ?? [:]
        return dictionary
    }
    
    func rejectNil(_ source: [String:Any?]) -> [String:Any]? {
        var destination = [String:Any]()
        for (key, nillableValue) in source {
            if let value: Any = nillableValue {
                destination[key] = value
            }
        }
        
        if destination.isEmpty {
            return nil
        }
        return destination
    }
}
