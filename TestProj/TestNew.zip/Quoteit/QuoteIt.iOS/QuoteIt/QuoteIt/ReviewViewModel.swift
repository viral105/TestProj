//
//  ReviewViewModel.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

class ReviewViewModel: Mappable {
    var reviewId: Int?
    var reviewDetail: String?
    var posterEmail: String?
    var jobId: Int?
    var reviewImage: String?
    var reviewOn: Date = Date()
    var reviewBy: UserProfileViewModel?
    var afterPhoto: String?
    
    required init(map: Mapper) throws {
        try reviewId = map.from("reviewId")
        reviewDetail = map.optionalFrom("reviewDetail")
        posterEmail = map.optionalFrom("posterEmail")
        jobId = map.optionalFrom("jobId")
        reviewImage = map.optionalFrom("reviewImage")
        reviewOn = map.parseDate("reviewOn")
        reviewBy = map.optionalFrom("reviewBy")
        afterPhoto = map.optionalFrom("afterPhoto")
    }
    
}
