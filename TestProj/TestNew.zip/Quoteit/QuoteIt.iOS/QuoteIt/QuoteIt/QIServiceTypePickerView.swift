//
//  DatePickerView.swift
//  parkatech
//
//  Created by Kuntal on 2017-06-24
//  Copyright © 2016 Weisetech Developers. All rights reserved.
//

import UIKit

class QIServiceTypePickerView: UIView, UIPickerViewDelegate, UIPickerViewDataSource {

    enum QIPickerType: Int {
        case service
        case city
    }
    
    static var PICKER_VIEW_HEIGHT: CGFloat = 260
    static var PICKER_VIEW_ANIMATION_DURATION: CGFloat = 0.25
    
    static var serviceTypePickerView :QIServiceTypePickerView?
    
    
    @IBOutlet weak var servicePicker: UIPickerView!
    
    var contentView: UIView!
    
    var didSelectServiceType: ((_ category: CategoryData) -> Void)?
    var didSelectCity: ((_ category: AddressData) -> Void)?
    
    var pickerType = QIPickerType.service
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView = setup()
        
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.25
        self.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.layer.shadowRadius = 3
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        contentView = setup()
    }


    @IBAction func didPressDatePickerDoneButton(_ sender: Any) {
        if pickerType == .service {
            if let didSelectServiceType = didSelectServiceType {
                if CacheService.categoriesList.count > servicePicker.selectedRow(inComponent: 0) {
                    let categoryData = CacheService.categoriesList[servicePicker.selectedRow(inComponent: 0)]
                    didSelectServiceType(categoryData)
                }
            }
        } else if pickerType == .city {
            if let didSelectCity = didSelectCity {
                if CacheService.citiesList.count > servicePicker.selectedRow(inComponent: 0) {
                    let cityData = CacheService.citiesList[servicePicker.selectedRow(inComponent: 0)]
                    didSelectCity(cityData)
                }
            }
        }
        
        removeView()
    }
    
    
    static func showToView(view: UIView?, selectedData: AnyObject?, pickerType: QIPickerType = .service) -> QIServiceTypePickerView {
        if let serviceTypePickerView = serviceTypePickerView {
            serviceTypePickerView.removeFromSuperview()
            QIServiceTypePickerView.serviceTypePickerView = nil
        }
        
        let pickerView = QIServiceTypePickerView(frame: CGRect(x: 0, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width, height: PICKER_VIEW_HEIGHT))
        pickerView.pickerType = pickerType
        
        serviceTypePickerView = pickerView
        if let view = view {
            view.addSubview(pickerView)
        }
        
        //, let selectedIndex = CacheService.categoriesList.index(of: selectedCategory)
        if pickerType == .service {
            if let selectedData = selectedData as? CategoryData, let selectedIndex = CacheService.categoriesList.index(where: {$0 === selectedData}) {
                pickerView.servicePicker.selectRow(selectedIndex, inComponent: 0, animated: false)
            }
        } else if pickerType == .city {
            if let selectedData = selectedData as? AddressData, let selectedIndex = CacheService.citiesList.index(where: {$0 === selectedData}) {
                pickerView.servicePicker.selectRow(selectedIndex, inComponent: 0, animated: false)
            }
        }
        
        
        
        UIView.animate(withDuration: TimeInterval(PICKER_VIEW_ANIMATION_DURATION), animations: {
            pickerView.frame = CGRect(x: 0, y: UIScreen.main.bounds.size.height - PICKER_VIEW_HEIGHT, width: UIScreen.main.bounds.size.width, height: PICKER_VIEW_HEIGHT)
            
        })
        
        return pickerView
    }
    
    
    func removeView() {
        QIServiceTypePickerView.serviceTypePickerView = nil
        UIView.animate(withDuration: TimeInterval(QIServiceTypePickerView.PICKER_VIEW_ANIMATION_DURATION), animations: {
            self.frame = CGRect(x: 0, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width, height: QIServiceTypePickerView.PICKER_VIEW_HEIGHT)
            self.perform(#selector(QIServiceTypePickerView.removeFromSuperview), with: nil, afterDelay: TimeInterval(QIServiceTypePickerView.PICKER_VIEW_ANIMATION_DURATION))
            
        })

    }
    
    // MARK:- UIPickerViewDelegate
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerType == .service {
            return CacheService.categoriesList.count
        } else if pickerType == .city {
            return CacheService.citiesList.count
        }
        return 0
    }
    
    public func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerType == .service {
            let category = CacheService.categoriesList[row]
            return category.name!
        } else if pickerType == .city {
            let city = CacheService.citiesList[row]
            return city.city!
        }
        return ""
        
    }
}


