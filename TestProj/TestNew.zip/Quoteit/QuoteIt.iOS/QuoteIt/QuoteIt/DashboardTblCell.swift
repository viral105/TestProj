//
//  DashboardMyJobsTblCell.swift
//  QuoteIt
//
//  Created by Viral Narshana on 9/2/17.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class DashboardTblCell: UITableViewCell {

    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblCategory: UILabel!
    @IBOutlet var lblStartDate: UILabel!
    @IBOutlet var lblAssignedTo: UILabel!
    @IBOutlet var lbldescription: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func updateHistoryView(historyData: JobViewModel) {
        if let hisTitle = historyData.title {
            lblTitle.text = hisTitle
        }
        
        if let hisCate = historyData.category {
            lblCategory.text = hisCate
        }
        
        if let startDate = self.timeAgoSinceDate(historyData.startDate) {
            lblStartDate.text = startDate
        }
        if let hisAssTo = historyData.assignedTo {
            lblAssignedTo.text = hisAssTo
        }
        if let hisDesc = historyData.description {
            lbldescription.text = hisDesc
        }
        
        
    }
    func updateFavouriteView(favData: FavouriteData) {
        if let favTitle = favData.jobTitle {
            lblTitle.text = favTitle
        }
        
        if let favCate = favData.jobCategory {
            lblCategory.text = String(favCate)
        }
        
        if let startDate = self.timeAgoSinceDate(favData.dateAdded) {
        lblStartDate.text = startDate
        }
        if let favAssTo = favData.poster?.displayName {
            lblAssignedTo.text = favAssTo
        }
        if let favDesc = favData.jobDetails {
            lbldescription.text = String(favDesc)
        }
        
        
    }
    
    func timeAgoSinceDate(_ date:Date, numericDates:Bool = false) -> String? {
        let calendar = NSCalendar.current
        let unitFlags: Set<Calendar.Component> = [.minute, .hour, .day, .weekOfYear, .month, .year, .second]
        let now = Date()
        let earliest = now < date ? now : date
        let latest = (earliest == now) ? date : now
        let components = calendar.dateComponents(unitFlags, from: earliest,  to: latest)
        
        if (components.year! >= 2) {
            return "\(components.year!) years ago"
        } else if (components.year! >= 1){
            if (numericDates){
                return "1 year ago"
            } else {
                return "Last year"
            }
        } else if (components.month! >= 2) {
            return "\(components.month!) months ago"
        } else if (components.month! >= 1){
            if (numericDates){
                return "1 month ago"
            } else {
                return "Last month"
            }
        } else if (components.weekOfYear! >= 2) {
            return "\(components.weekOfYear!) weeks ago"
        } else if (components.weekOfYear! >= 1){
            if (numericDates){
                return "1 week ago"
            } else {
                return "Last week"
            }
        } else if (components.day! >= 2) {
            return "\(components.day!) days ago"
        } else if (components.day! >= 1){
            if (numericDates){
                return "1 day ago"
            } else {
                return "Yesterday"
            }
        } else if (components.hour! >= 2) {
            return "\(components.hour!) hours ago"
        } else if (components.hour! >= 1){
            if (numericDates){
                return "1 hour ago"
            } else {
                return "An hour ago"
            }
        } else if (components.minute! >= 2) {
            return "\(components.minute!) minutes ago"
        } else if (components.minute! >= 1){
            if (numericDates){
                return "1 minute ago"
            } else {
                return "A minute ago"
            }
        } else if (components.second! >= 3) {
            return "\(components.second!) seconds ago"
        } else {
            return "Just now"
        }
        
    }

}
