//
//  CurrentLocationButton.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-08-03.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class QISearchAddress: UIView, UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate {

    var contentView: UIView!
    
    
    @IBOutlet weak var searchView: UIView!
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var locationSuggestionTableView: UITableView!
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    
    
    var delegate: QISearchAddressDelegate!
    
    var matchingLocations: [MKMapItem] = []
    
    var LOCATION_SUGGESTION_CELL_HEIGHT: CGFloat = 50
    
    var isForParkTab = false
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    func setupView() {
        contentView = setup()
        
        searchView.layer.cornerRadius = 3.0
        
        searchTextField.delegate = self
        
        searchView.layer.shadowColor = UIColor.black.cgColor
        searchView.layer.shadowOpacity = 0.5
        searchView.layer.shadowOffset = CGSize.zero
        searchView.layer.shadowRadius = 3
        
        //searchTextField.font = UIFont.appWideRegularFont(size: 14)
        searchTextField.clearButtonMode = .always
        searchTextField.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: UIControlEvents.editingChanged)
        
        locationSuggestionTableView.tableFooterView = UIView(frame: CGRect.zero)
        locationSuggestionTableView.bounces = false
        clearSearchField()
        
        
        searchTextField.becomeFirstResponder()
        
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.QIPinkColor
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Cancel", style: .done, target: self, action: #selector(didPressCancelButton))
        toolBar.setItems([spaceButton, doneButton], animated: false)
        
        
        toolBar.isUserInteractionEnabled = true
        toolBar.sizeToFit()
        
        searchTextField.inputAccessoryView = toolBar
        
    }
    
    // MARK:- UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //textField.resignFirstResponder()
        return true
    }
    @objc private func textFieldDidChange(textField: UITextField!) {
        
        if textField.text?.length == 0 {
            clearSearchField()
            return
        }
        let request = MKLocalSearchRequest()
        request.naturalLanguageQuery = textField.text!
        let search = MKLocalSearch(request: request)
        search.start { response, _ in
            guard let response = response else {
                return
            }
            self.matchingLocations = response.mapItems
            self.locationSuggestionTableView.reloadData()
            self.tableViewHeight.constant = min(180, self.LOCATION_SUGGESTION_CELL_HEIGHT * CGFloat(self.matchingLocations.count))
        }
    }
    
    func clearSearchField() {
        self.matchingLocations = []
        self.locationSuggestionTableView.reloadData()
        self.tableViewHeight.constant = min(180, self.LOCATION_SUGGESTION_CELL_HEIGHT * CGFloat(self.matchingLocations.count))
    }
    
    // location
    func didUpdateCurrentLocation(location: CLLocation) {
        let coordinations = CLLocationCoordinate2D(latitude: location.coordinate.latitude,longitude: location.coordinate.longitude)
        let span = MKCoordinateSpanMake(0.2,0.2)
        let region = MKCoordinateRegion(center: coordinations, span: span)
    }
    
    // MARK:- UITableViewDelegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.matchingLocations.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return LOCATION_SUGGESTION_CELL_HEIGHT
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier = "locationSuggestionCell"
        var cell = tableView.dequeueReusableCell(withIdentifier: identifier)
        
        if cell == nil {
            cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: identifier)
        }
        
        //cell?.textLabel?.font = UIFont.appWideRegularFont(size: 12)
        cell?.textLabel?.numberOfLines = 0
        
        let selectedItem = matchingLocations[(indexPath as NSIndexPath).row].placemark
        cell?.imageView?.contentMode = .center
        cell?.imageView?.image = UIImage(named: "location_marker_dark_gray")
        cell?.textLabel?.text = selectedItem.parseAddress()
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedItem = matchingLocations[(indexPath as NSIndexPath).row].placemark
        addSelectedLocationAnnotation(selectedItem)
        clearSearchField()
        searchTextField.text = ""
        searchTextField.resignFirstResponder()
        
        
    }
    
    func addSelectedLocationAnnotation(_ placemark:MKPlacemark) {
        
        
        let addressString = placemark.parseAddress()
        
        let lat = placemark.coordinate.latitude
        let long = placemark.coordinate.longitude
        
        self.removeFromSuperview()
        
        delegate.didSelectLocation(name: addressString, latitute: lat, longitute: long)
        
    }
    
    
    
    
    func didPressCancelButton() {
        self.removeFromSuperview()
    }
    
    

}

protocol QISearchAddressDelegate {
    func didSelectLocation(name: String, latitute: Double, longitute: Double)
}
