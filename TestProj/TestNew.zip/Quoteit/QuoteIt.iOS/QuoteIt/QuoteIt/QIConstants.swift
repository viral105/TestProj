//
//  QIConstants.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-22.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import UIKit

let appDelegate = UIApplication.shared.delegate as! AppDelegate

let MAIN_STORY_BORAD = "Main"
let LOGGED_IN_USER_STORY_BORAD = "LoggedInUser"

let IMAGE_ASPECT_RATIO: CGFloat = (2.2/4.0)
