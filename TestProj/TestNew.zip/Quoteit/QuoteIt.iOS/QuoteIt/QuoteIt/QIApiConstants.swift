//
//  QIApiConstants.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-20.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation

let BASE_URL = "http://kainat.ca:82/api/"

let GET_KEY_WORD_LIST = "keywordlist"
let GET_CITY_LIST = "citylist"
let GET_DETAIL_CITY_LIST = "detailcitylist"
let GET_CATEGORY_LIST = "categorylist"
let GET_USER_ALERT_LIST = "UserAlerts"
let GET_JOB_LIST = "Jobs"
let GET_JOB_DETAIL = "JobDetail"

let GET_DASHBOARD_JOBS = "DashboardJobs"
let GET_HIRSOTIES = "Histories"
let GET_FAVOURITE = "Favorites"
