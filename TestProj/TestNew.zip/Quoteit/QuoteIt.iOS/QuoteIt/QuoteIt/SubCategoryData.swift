//
//  SubCategoriesData.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-20.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

class SubCategoryData: Mappable {
    var subCatID: Int?
    var subCatName: String?
    var parentID: Int??
    
    
    required init(map: Mapper) throws {
        try subCatID = map.from("subCatID")
        subCatName = map.optionalFrom("subCatName")
        parentID = map.optionalFrom("parentID")
    }
}
