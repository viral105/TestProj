//
//  QIError.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-20.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation

class QIError {
    var message: String = ""
    
    static func parseFromJson(json: NSDictionary) -> QIError? {
        if let message = json["message"] as? String {
            let error = QIError()
            error.message = message
            return error
        }
        return nil
    }
    
    static func getError(message: String) -> QIError {
        let error = QIError()
        error.message = message
        return error
    }
    
}
