//
//  QIViewControllerExtension.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-22.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import UIKit
import GSMessages
import SlideMenuControllerSwift
import MBProgressHUD

extension UIViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func showSlidingErrorMessage(errorString: String) {
        GSMessage.errorBackgroundColor   = UIColor(red: 219.0/255, green: 36.0/255,  blue: 27.0/255,  alpha: 1.0)
        self.showMessage(errorString, type: GSMessageType.error, options: [.position(.top)])
    }
    
    func setDismissButton() {
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "back_button"), style: UIBarButtonItemStyle.plain, target: self, action:#selector(UIViewController.dismissNavigationController))
    }
    
    func dismissNavigationController() {
        self.dismiss(animated: true, completion: nil)
    }
    // MARK:- SHOW ALERT CONTROLLER
    func showAlertController(title: String?, message: String?, leftAction: UIAlertAction, rightAction: UIAlertAction) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(leftAction)
        alertController.addAction(rightAction)
        self.present(alertController, animated: false, completion: nil)
    }
    
    func showAlert(title: String?, message: String?, cancelBottonTitle: String, okButtonTitle: String? = nil, okAction: ((UIAlertAction) -> Swift.Void)? = nil) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        if let okButtonTitle = okButtonTitle {
            let okAction = UIAlertAction(title: okButtonTitle, style: UIAlertActionStyle.cancel, handler: okAction)
            alertController.addAction(okAction)
        }
        
        let cancelAction = UIAlertAction(title: cancelBottonTitle, style: UIAlertActionStyle.cancel, handler: nil)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: false, completion: nil)
    }
    
    // MARK:- SHOW IMAGE PCIKER
    func showImagePickerOption() {
        let alertController = UIAlertController(title: "Selection Option", message: "", preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default) { (action) in
            self.openImagePickerController(isCamera: true)
        }
        
        let galleryAction = UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default) { (action) in
            self.openImagePickerController(isCamera: false)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertController.addAction(cameraAction)
        alertController.addAction(galleryAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    func openImagePickerController(isCamera: Bool) {
        let picker = UIImagePickerController()
        //picker.allowsEditing = true
        if isCamera {
            picker.sourceType = .camera
        } else {
            picker.sourceType = .photoLibrary
        }
        picker.delegate = self
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker, animated: true, completion: nil)
        
    }
    
    // MARK:- UIImagePickerControllerDelegate Methods
    public func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let chosenImage = info[UIImagePickerControllerEditedImage] as? UIImage{
            imagePickerDidSelectImage(chosenImage: chosenImage)
        } else {
            let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
            imagePickerDidSelectImage(chosenImage: chosenImage)
        }
        
        dismiss(animated:true, completion: nil)
    }
    
    func imagePickerDidSelectImage(chosenImage: UIImage) {
        
    }
    
    // MARK:- Login/Logout User
    // TODO:- Pass login user object
    func loginUser(accessToken: AccessToken) {
        Global.accessToken = accessToken
        SlideMenuOptions.leftViewWidth = 300
        SlideMenuOptions.contentViewScale = 1.0
        
        let tabBarController = UIStoryboard(name: LOGGED_IN_USER_STORY_BORAD, bundle: nil).instantiateViewController(withIdentifier: "LoggedInUserTabBarViewController")
        let leftMenuViewController = LeftMenuViewController.initFromStoryBoard()
        
        let slideMenuController = SlideMenuController(mainViewController: tabBarController, leftMenuViewController: leftMenuViewController)
        appDelegate.window?.rootViewController = slideMenuController
        appDelegate.window?.makeKeyAndVisible()
    }
    
    
    func setMenuButton() {
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "hamburger"), style: UIBarButtonItemStyle.plain, target: self, action: #selector(showMenu))
    }
    
    func showMenu() {
        self.slideMenuController()?.openLeft()
    }
    
    func showLoader() {
        MBProgressHUD.showAdded(to: self.view, animated: false)
    }
    
    func hideLoader() {
        MBProgressHUD.hide(for: self.view, animated: false)
    }
    
}
