//
//  KeywordData.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-20.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation

class KeywordData {
    var keywordID: Int?
    var keywordName: String?
    var parentCategory: String?
    
    required init(withDictionary dictionary: [String: Any]) {
        keywordID = dictionary["keywordID"] as? Int
        keywordName = dictionary["keywordName"] as? String
        parentCategory = dictionary["parentCategory"] as? String
    }    
}
