//
//  QIFonts.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-05.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import UIKit

enum FontWeight: Int {
    case light
    case regular
    case medium
    case heavy
    
    func getFontFamily() -> String {
        switch self {
        case .light:
            return UIFont.AVENIR_LIGHT
        case .regular:
            return UIFont.AVENIR_BOOK
        case .medium:
            return UIFont.AVENIR_MEDIUM
        case .heavy:
            return UIFont.AVENIR_HEAVY
        
        }
    }
}
extension UIFont {
    static let AVENIR_BOOK = "Avenir-Book"
    static let AVENIR_MEDIUM = "Avenir-Medium"
    static let AVENIR_HEAVY_OBLIQUE = "Avenir-HeavyOblique"
    static let AVENIR_LIGHT = "Avenir-Light"
    static let AVENIR_ROMAN = "Avenir-Roman"
    static let AVENIR_BOOK_OBLIQUE = "Avenir-BookOblique"
    static let AVENIR_MEDUIM_OBLIQUE = "Avenir-MediumOblique"
    static let AVENIR_BLACK = "Avenir-Black"
    static let AVENIR_BLACK_OBLIQUE = "Avenir-BlackOblique"
    static let AVENIR_HEAVY = "Avenir-Heavy"
    static let AVENIR_LIGHT_OBLIQUE = "Avenir-LightOblique"
    static let AVENIR_OBLIQUE = "Avenir-Oblique"
    
    
    static let titleFont = UIFont(name: AVENIR_BOOK, size: 14)
    static let subTitleFont = UIFont(name: AVENIR_BOOK, size: 12)
    
    
    static func fontWithWeight(weight: FontWeight, size: CGFloat) -> UIFont {
        return UIFont(name: weight.getFontFamily(), size: size)!
    }
    
    
}
