//
//  QITextField.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-19.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

@IBDesignable

class QITextField: UITextField {

    var leftImageView = UIImageView()
    var rightImageView = UIImageView()
    
    
    var imageViewWidth: CGFloat = 30;
    var imageViewHeight: CGFloat = 30
    
    var showPassword: Bool = false {
        didSet {
            if showPassword {
                rightImageView.image = UIImage(named: "")
                rightImageView.backgroundColor = UIColor.red
                self.isSecureTextEntry = false
            } else {
                rightImageView.image = UIImage(named: "")
                self.isSecureTextEntry = true
                rightImageView.backgroundColor = UIColor.green
            }
        }
    }
    @IBInspectable var iconImageName: String = "" {
        didSet {
            if iconImageName.length > 0 {
                leftImageView.image = UIImage(named: iconImageName)
                leftImageView.frame = CGRect(x: 0, y: (self.frame.size.height - imageViewHeight)/2.0, width: imageViewWidth, height: imageViewHeight)
                self.leftView = leftImageView
                self.leftViewMode = UITextFieldViewMode.always
            }
        }
    }
    
    @IBInspectable var isForPassword: Bool = false {
        didSet {
            if isForPassword {
                showPassword = false
                let rightView = UIView(frame: CGRect(x: 0, y: 0, width: 30, height: self.frame.size.height))
                rightImageView.frame = CGRect(x: 0, y: (self.frame.size.height - imageViewHeight)/2.0, width: imageViewWidth, height: imageViewHeight);
                rightImageView.contentMode = .scaleAspectFit
                rightView.addSubview(rightImageView)
                
                let showPasswordButton = UIButton()
                showPasswordButton.frame = rightView.bounds;
                showPasswordButton.addTarget(self, action: #selector(QITextField.didPressShowPassWordButton), for: UIControlEvents.touchUpInside)
                rightView.addSubview(showPasswordButton)
                
                self.rightView = rightView
                self.rightViewMode = UITextFieldViewMode.always
            } else {
                self.rightViewMode = UITextFieldViewMode.never
            }
        }
    }
    
    func didPressShowPassWordButton() {
        showPassword = !showPassword
    }
    
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        let context = UIGraphicsGetCurrentContext()
        let lineWidth : CGFloat = 1.0
        context?.setLineWidth(lineWidth)
        context?.setStrokeColor(UIColor.graySeperatorColor.cgColor)
        context?.move(to: CGPoint(x: 0, y: self.frame.size.height - lineWidth))
        context?.addLine(to: CGPoint(x: self.frame.size.width, y: self.frame.size.height - lineWidth))
        context?.strokePath()
    }
    

}
