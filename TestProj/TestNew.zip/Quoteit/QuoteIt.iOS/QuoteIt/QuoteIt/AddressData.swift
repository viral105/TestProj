//
//  AddressData.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-20.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

class AddressData: Mappable {
    var addressID: Int?
    var city: String?
    var parentCity: String?
    
    
    required init(map: Mapper) throws {
        try addressID = map.from("addressID")
        city = map.optionalFrom("city")
        parentCity = map.optionalFrom("parentCity")
    }
}
