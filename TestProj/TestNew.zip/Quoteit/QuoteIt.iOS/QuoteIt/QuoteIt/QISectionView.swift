//
//  QISectionView.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-22.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

@IBDesignable
class QISectionView: UIView {
    
    @IBInspectable var boderColor: UIColor = UIColor.graySeperatorColor {
        didSet {
            setNeedsDisplay()
        }
    }
    override func draw(_ rect: CGRect) {
        // Drawing code
        let context = UIGraphicsGetCurrentContext()
        let lineWidth : CGFloat = 1.0
        context?.setLineWidth(lineWidth)
        context?.setStrokeColor(boderColor.cgColor)
        context?.move(to: CGPoint(x: 0, y: self.frame.size.height - lineWidth))
        context?.addLine(to: CGPoint(x: self.frame.size.width, y: self.frame.size.height - lineWidth))
        context?.strokePath()
    }
}
