//
//  QITabView.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-28.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class QITabView: UIView {
    @IBOutlet weak var tabImageView: UIImageView!
    @IBOutlet weak var tablTitleLabel: UILabel!
    @IBOutlet weak var tablSelectionView: UIView!
    
    var selectTab: ((Swift.Void) -> Void)? = nil
    var selected: Bool = false {
        didSet {
            if selected {
                tablSelectionView.isHidden = false
                contentView?.backgroundColor = UIColor(white: 0.1, alpha: 1.0)
            } else {
                tablSelectionView.isHidden = true
                contentView?.backgroundColor = UIColor.black
            }
        }
    }
    
    var imageName: String = "" {
        didSet {
            tabImageView.contentMode = UIViewContentMode.center
            tabImageView.tintColor = UIColor.white
            tabImageView.image = UIImage(named: imageName)?.withRenderingMode(UIImageRenderingMode.alwaysTemplate)
        }
    }
    
    var title: String = "" {
        didSet {
            tablTitleLabel.text = title
        }
    }
    
    var contentView: UIView? = nil
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    
    func setupView() {
        contentView = setup()
        selected = false
    }
    @IBAction func didSelectTab(_ sender: Any) {
        if let selectTab = selectTab {
            selectTab()
        }
    }


}
