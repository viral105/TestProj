//
//  CurrentLocationButton.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-08-03.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import CoreLocation

class QILocationManager: NSObject, CLLocationManagerDelegate {
    
    static let sharedLocationManager = QILocationManager()
    
    var currentLocation: CLLocation?
    
    var locationManager = CLLocationManager()
    
    var didUpdateLocation: ((_ location: CLLocation?) -> Void)?
    
    override init() {
        super.init()
    }
    
    
    func locateMe() {
        if let currentLocation = currentLocation {
            
            if let didUpdateLocation = didUpdateLocation {
                didUpdateLocation(currentLocation)
            }
            return
        }
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLocation:CLLocation = locations[0] as CLLocation
        currentLocation = userLocation
        locationManager.stopUpdatingLocation()
        if let didUpdateLocation = didUpdateLocation {
            didUpdateLocation(userLocation)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        if let didUpdateLocation = didUpdateLocation {
            didUpdateLocation(nil)
        }
    }
}
