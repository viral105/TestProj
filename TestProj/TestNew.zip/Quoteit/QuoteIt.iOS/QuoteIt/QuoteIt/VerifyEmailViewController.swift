//
//  VerifyEmailViewController.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-24.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class VerifyEmailViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var checkYourEmailLabel: UILabel!
    @IBOutlet weak var titleLabel1: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var titleLabel2: UILabel!
    @IBOutlet weak var verficationTextField: UITextField!
    
    static func initFromStoryBoard() -> VerifyEmailViewController {
        return UIStoryboard(name: MAIN_STORY_BORAD, bundle: nil).instantiateViewController(withIdentifier: "VerifyEmailViewController") as! VerifyEmailViewController
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel1.textColor = UIColor.QIGrayTextColor
        titleLabel2.textColor = UIColor.QIGrayTextColor
        emailLabel.text = SignupRequest.user?.Email
        
        checkYourEmailLabel.layer.borderWidth = 1.0
        checkYourEmailLabel.layer.borderColor = UIColor.graySeperatorColor.cgColor
        
        verficationTextField.layer.borderWidth = 1.0
        verficationTextField.layer.borderColor = UIColor.graySeperatorColor.cgColor
        
        self.navigationItem.title = "Verify Email"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func didPressVerifyButton(_ sender: Any) {
        showLoader()
        UserService.verifyEmailCode(code: verficationTextField.getText()) { (error) in
            self.hideLoader()
            if let error = error {
                self.showSlidingErrorMessage(errorString: error.message)
            } else {
                Global.accessToken?.emailConfirmed = true
                self.loginUser(accessToken: Global.accessToken!)
            }
        }
    }

    
    // MARK:- UITextField Delegate
    public func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
