//
//  ImageSelectionData.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-11.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import UIKit

class ImageSelectionData {
    var selectedImages: [UIImage] = []
}
