//
//  DashbFavouriteVC.swift
//  QuoteIt
//
//  Created by Viral Narshana on 9/10/17.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class DashbFavouriteVC: UIViewController {

    @IBOutlet weak var favouriteTableView: UITableView!
    @IBOutlet weak var favouriteActivityIndicatorView: UIActivityIndicatorView!
    
    let refreshController = UIRefreshControl()
    var favouriteArray: [FavouriteData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        refreshController.addTarget(self, action: #selector(loadFavourites), for: UIControlEvents.valueChanged)
        favouriteTableView.addSubview(refreshController)
        
        loadFavourites()
    }
    
    func loadFavourites() {
        DashboardService.loadFavoutires { (favourites, error) in
            self.favouriteActivityIndicatorView.stopAnimating()
            if let error = error {
                self.showSlidingErrorMessage(errorString: error.message)
            } else {
                self.favouriteArray.append(contentsOf: favourites)
                
                print(self.favouriteArray[0])
            }
            self.favouriteTableView.reloadData()
            self.refreshController.endRefreshing()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension DashbFavouriteVC: UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favouriteArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{

            return 170

    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: DashboardTblCell
        let favData = favouriteArray[indexPath.row]
        
            cell = tableView.dequeueReusableCell(withIdentifier: "FavouriteCell") as! DashboardTblCell
            
            cell.updateFavouriteView(favData: favData)
        
        return cell
    }
}
