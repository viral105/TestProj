//
//  JobsFeedViewModel.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-09-25.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

class JobsFeedViewModel: Mappable {
    var jobID: Int?
    var title : String?
    var quotes: [QuoteViewModel] = []
    var isJobFavorite: Bool?
    var categoryThumbnail: String?
    var categoryCommissionAmount: Float? = 0.0
    var quoteId: Int?
    var posterId: String?
    var posterName: String?
    var posterAvatar: String?
    var email: String?
    var lat: Double? = 0.0
    var lng: Double? = 0.0
    var city: String?
    var categoryID: Int? = 0
    var startDate: Date?
    var expiryDate: Date?
    var detail: String?
    var category: String?
    var thumbnail: String?
    var imagesCount: Int?
    var userBadge: Int?
    var distance: Double?
    var acceptedQuotes: Int?
    var deleted: Bool?
    
    required init(map: Mapper) throws {
        try jobID = map.from("jobID")
        title = map.optionalFrom("title")
        let quotesOptional: [QuoteViewModel]? = map.optionalFrom("quotes")
        if let quotesOptional = quotesOptional {
            self.quotes = quotesOptional
        }
        isJobFavorite = map.optionalFrom("isJobFavorite")
        
        categoryThumbnail = map.optionalFrom("categoryThumbnail")
        categoryCommissionAmount = map.optionalFrom("categoryCommissionAmount")
        quoteId = map.optionalFrom("quoteId")
        posterId = map.optionalFrom("posterId")
        posterName = map.optionalFrom("posterName")
        posterAvatar = map.optionalFrom("posterAvatar")
        email = map.optionalFrom("email")
        lat = map.optionalFrom("lat")
        lng = map.optionalFrom("lng")
        city = map.optionalFrom("city")
        categoryID = map.optionalFrom("categoryID")
        startDate = map.parseDate("startDate")
        expiryDate = map.parseDate("expiryDate")
        detail = map.optionalFrom("detail")
        category = map.optionalFrom("category")
        thumbnail = map.optionalFrom("thumbnail")
        imagesCount = map.optionalFrom("imagesCount")
        userBadge = map.optionalFrom("userBadge")
        distance = map.optionalFrom("distance")
        acceptedQuotes = map.optionalFrom("acceptedQuotes")
        deleted = map.optionalFrom("deleted")
        
        
    }
}
