//
//  CompanySignup2Controller.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-22.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class CompanySignup2Controller: UIViewController, QISearchAddressDelegate {
    
    @IBOutlet weak var businessAddressTextField: UITextField!
    
    @IBOutlet weak var radiusSlider: UISlider!
    @IBOutlet weak var radiusLabel: UILabel!
    
    @IBOutlet weak var singleServiceSelectionView1: QISingleServiceSelectionView!
    @IBOutlet weak var singleServiceSelectionView2: QISingleServiceSelectionView!
    @IBOutlet weak var singleServiceSelectionView3: QISingleServiceSelectionView!
    @IBOutlet weak var singleServiceSelectionView4: QISingleServiceSelectionView!
    @IBOutlet weak var singleServiceSelectionView5: QISingleServiceSelectionView!
    
    
    @IBOutlet weak var termsAndConditionButton: UIButton!
    
    @IBOutlet weak var checkmarkTAndCButton: UIButton!
    
    @IBOutlet weak var currenLocationButton: CurrentLocationButton!
    
    var termsAndConditionAccepted = true
    
    var latitute: Double = 0.0
    var longitute: Double = 0.0
    
    static func initFromStoryBoard() -> CompanySignup2Controller {
        return UIStoryboard(name: MAIN_STORY_BORAD, bundle: nil).instantiateViewController(withIdentifier: "CompanySignup2Controller") as! CompanySignup2Controller
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "SIGN UP"
        
        currenLocationButton.didSelectLocation = { (address, latitute, longitute) in
            self.businessAddressTextField.text = address
            self.latitute = latitute
            self.longitute = longitute
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK:- Button Press Events
    @IBAction func didChangeRadius(_ sender: Any) {
        radiusLabel.text = String(format: "%.0f KM", radiusSlider.value)
    }
    
    @IBAction func didPressCheckMarkButton(_ sender: Any) {
        
    }
    @IBAction func didPressContinueButton(_ sender: Any) {
        let addressString = businessAddressTextField.getText()
        let radius = radiusSlider.value
        let categoryData1 = singleServiceSelectionView1.selectedCategory
        let categoryData2 = singleServiceSelectionView2.selectedCategory
        let categoryData3 = singleServiceSelectionView3.selectedCategory
        let categoryData4 = singleServiceSelectionView4.selectedCategory
        let categoryData5 = singleServiceSelectionView5.selectedCategory
        
        
        if addressString.length == 0 {
            self.showSlidingErrorMessage(errorString: ERROR_ENTER_BUSINESS_ADDRESS)
            return;
        }
        
        if radius == 0 {
            self.showSlidingErrorMessage(errorString: ERROR_SELECT_RADIUS)
            return;
        }
        
        guard let _ = categoryData1 else {
            self.showSlidingErrorMessage(errorString: ERROR_BUSINESS_CATEGORY)
            return;
        }
        
        if let categoryData1 = categoryData1 {
            SignupRequest.user?.UserCategories.append(categoryData1.categoryID!)
        }
        if let categoryData2 = categoryData2 {
            SignupRequest.user?.UserCategories.append(categoryData2.categoryID!)
        }
        if let categoryData3 = categoryData3 {
            SignupRequest.user?.UserCategories.append(categoryData3.categoryID!)
        }
        if let categoryData4 = categoryData4 {
            SignupRequest.user?.UserCategories.append(categoryData4.categoryID!)
        }
        if let categoryData5 = categoryData5 {
            SignupRequest.user?.UserCategories.append(categoryData5.categoryID!)
        }
        
        SignupRequest.user?.Address = addressString
        //SignupRequest.distance = "\(radius)"
        self.showLoader()
        UserService.createUser(user: SignupRequest.user!, completion: { (accessToken, error) in
            self.hideLoader()
            if let accessToken = accessToken {
                if let emailConfirmed = accessToken.emailConfirmed, emailConfirmed == true {
                    self.loginUser(accessToken: accessToken)
                } else {
                    Global.accessToken = accessToken
                    let verifyEmailViewController = VerifyEmailViewController.initFromStoryBoard()
                    self.navigationController?.pushViewController(verifyEmailViewController, animated: true)
                }
            } else {
                self.showSlidingErrorMessage(errorString: error!.message)
            }
        })
        
        
    }
    @IBAction func didPressSelectLocationButton(_ sender: Any) {
        let searchAddress = QISearchAddress(frame: self.view.bounds)
        searchAddress.delegate = self
        self.view.addSubview(searchAddress)
    }
    
    // MARK:- Search Address Delegate
    func didSelectLocation(name: String, latitute: Double, longitute: Double) {
        businessAddressTextField.text = name
        self.latitute = latitute
        self.longitute = longitute
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
