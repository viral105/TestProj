//
//  QIColors.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-19.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import UIKit

extension UIColor {
    static let primaryColor = UIColor.colorWithRGB(red: 255, green: 51, blue: 102)
    
    static let QIPinkColor = UIColor.colorWithRGB(red: 255, green: 51, blue: 102)
    
    static let graySeperatorColor = UIColor.colorWithRGB(red: 230, green: 230, blue: 230)
    
    static let QIGrayTextColor = UIColor.colorWithRGB(red: 180, green: 180, blue: 180)
    
    static let QIDarkGraytColor = UIColor.colorWithRGB(red: 100, green: 100, blue: 100)
    
    static func colorWithRGB(red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat = 1.0) -> UIColor {
        return UIColor(red: red/255.0, green: green/255.0, blue: blue/255.0, alpha: alpha)
    }
    
}
