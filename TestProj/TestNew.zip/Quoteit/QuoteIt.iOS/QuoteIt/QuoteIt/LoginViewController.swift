//
//  LoginViewController.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-19.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit
import MBProgressHUD

class LoginViewController: UIViewController {

    @IBOutlet weak var emailAddressTextField: QITextField!
    
    @IBOutlet weak var passwordTextField: QITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "LOGIN"
        setDismissButton()
        
        //emailAddressTextField.text = "waheed@techservicesstudio.com"
        emailAddressTextField.text = "shahzad@techservicesstudio.com"
        //j1958227@mvrht.net Qwert123
        passwordTextField.text = "Letmein"
        
        
        /*for familyName in UIFont.familyNames {
            print("********************")
            print("familyName \(familyName)")
            for fontName in UIFont.fontNames(forFamilyName: familyName) {
                print("fontName \(fontName)")
            }
        }*/
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK:- Button press evetns
    
    @IBAction func didPressSignInButton(_ sender: Any) {
        
        let username = emailAddressTextField.getText()
        let password = passwordTextField.getText()
        
        if username.length == 0 {
            self.showSlidingErrorMessage(errorString: ERROR_ENTER_EMAIL_ADDRESS)
        }
        
        if password.length < 7 {
            self.showSlidingErrorMessage(errorString: ERROR_PASSWORD_IS_NOT_8_CHARACTERS_LONG)
        }
        
        
        MBProgressHUD.showAdded(to: self.view, animated: true)
        UserService.getAccessTokenForLocalUser(username: username, password: password) { (accessToken, error) in
            MBProgressHUD.hide(for: self.view, animated: true)
            if let error = error {
                self.showSlidingErrorMessage(errorString: error.message)
            } else {
                self.navigationController?.dismiss(animated: false, completion: nil)
                self.loginUser(accessToken: accessToken!)
            }
        }
        
    }
    
    @IBAction func didPressLoginWithFaceBook(_ sender: Any) {
        QIFBLoginHelper.loginWithFaceBook(forViewController: self) { (emailAddress, result, error) in
            if let emailAddress = emailAddress {
                self.showAlert(title: "FaceBook Login", message: "Login with facebok with email adress \(emailAddress)", cancelBottonTitle: "OK")
            }
        }
    }
    
    @IBAction func didPressLoginWithGoogle(_ sender: Any) {
        
    }
    
    // MARK:- UITextField Delegate Methods
    public func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    

}
