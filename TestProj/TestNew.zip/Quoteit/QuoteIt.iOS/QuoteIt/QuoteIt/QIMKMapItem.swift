//
//  QIMKMapItem.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-08-03.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import MapKit

extension CLPlacemark {
    
    func parseAddress() -> String {
        // put a space between "4" and "Melrose Place"
        let firstSpace = (self.subThoroughfare != nil && self.thoroughfare != nil) ? " " : ""
        // put a comma between street and city/state
        let comma = (self.subThoroughfare != nil || self.thoroughfare != nil) && (self.subAdministrativeArea != nil || self.administrativeArea != nil) ? ", " : ""
        // put a space between "Washington" and "DC"
        let secondSpace = (self.subAdministrativeArea != nil && self.administrativeArea != nil) ? " " : ""
        let addressLine = String(
            format:"%@%@%@%@%@%@%@",
            // street number
            self.subThoroughfare ?? "",
            firstSpace,
            // street name
            self.thoroughfare ?? "",
            comma,
            // city
            self.locality ?? "",
            secondSpace,
            // state
            self.administrativeArea ?? ""
        )
        return addressLine
    }
    
}

//extension CLPlacemark {
//    
//    func parseAddress() -> String {
//        // put a space between "4" and "Melrose Place"
//        let firstSpace = (self.subThoroughfare != nil && self.thoroughfare != nil) ? " " : ""
//        // put a comma between street and city/state
//        let comma = (self.subThoroughfare != nil || self.thoroughfare != nil) && (self.subAdministrativeArea != nil || self.administrativeArea != nil) ? ", " : ""
//        // put a space between "Washington" and "DC"
//        let secondSpace = (self.subAdministrativeArea != nil && self.administrativeArea != nil) ? " " : ""
//        let addressLine = String(
//            format:"%@%@%@%@%@%@%@",
//            // street number
//            self.subThoroughfare ?? "",
//            firstSpace,
//            // street name
//            self.thoroughfare ?? "",
//            comma,
//            // city
//            self.locality ?? "",
//            secondSpace,
//            // state
//            self.administrativeArea ?? ""
//        )
//        return addressLine
//    }
//    
//}
//

