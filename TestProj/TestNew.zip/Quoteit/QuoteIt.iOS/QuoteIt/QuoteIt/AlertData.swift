//
//  AlertData.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-17.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper


class AlertData: Mappable {
    var id: Int?
    var alertId: Int?
    var alertTitle: String?
    var alertType: String?
    var userId: String?
    var jobId: Int?
    var quoteId: Int?
    var commentId: Int?
    var replyId: Int?
    var alertDate: Date?
    var alertDateToDisplay: String?
    var quotePrice: Float?
    var isRead: Bool?
    
    
    required init(map: Mapper) throws {
        try id = map.from("id")
        alertId = map.optionalFrom("alertId")
        alertTitle = map.optionalFrom("alertTitle")
        alertType = map.optionalFrom("alertType")
        userId = map.optionalFrom("userId")
        jobId = map.optionalFrom("jobId")
        quoteId = map.optionalFrom("quoteId")
        commentId = map.optionalFrom("commentId")
        replyId = map.optionalFrom("replyId")
        
        alertDate = map.parseDate("alertDate")
        alertDateToDisplay = alertDate?.getAlertDisplayString()
        quotePrice = map.optionalFrom("quotePrice")
        isRead = map.optionalFrom("isRead")
        
    }

}
