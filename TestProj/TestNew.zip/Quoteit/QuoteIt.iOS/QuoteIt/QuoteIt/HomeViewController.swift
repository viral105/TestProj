//
//  ViewController.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-19.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        loadKeyWords()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func loadKeyWords() {
        CacheService.getKeyWords { (_) in
            self.loadCities()
        }
    }
    
    func loadCities() {
        CacheService.getCities { (_) in
            self.loadDetailCities()
        }
    }
    
    func loadDetailCities() {
        CacheService.getDetailCities { (_) in
            self.loadCategories()
        }
    }
    
    func loadCategories() {
        CacheService.getCategories { (_) in
            
        }
    }
    
    @IBAction func didPressSignupButton(sender: Any) {
        
        let needJobDoneAction = UIAlertAction(title: "NEED JOB DONE", style: UIAlertActionStyle.default) { (action) in
            let companySignup1Controller = CompanySignup1Controller.initFromStoryBoard()
            companySignup1Controller.isNotForCompany = true
            let navigationController = QIBaseNavigationViewController(rootViewController: companySignup1Controller)
            self.present(navigationController, animated: true, completion: nil)
        }
        
        let serviceProviderAction = UIAlertAction(title: "Service Provider".uppercased(), style: UIAlertActionStyle.default) { (action) in
            let companySignup1Controller = CompanySignup1Controller.initFromStoryBoard()
            let navigationController = QIBaseNavigationViewController(rootViewController: companySignup1Controller)
            self.present(navigationController, animated: true, completion: nil)
        }
        
        showAlertController(title: nil, message: "Do you need a job done\nor\nAre you a service provider?".uppercased(), leftAction: needJobDoneAction, rightAction: serviceProviderAction)
        
    }

}

