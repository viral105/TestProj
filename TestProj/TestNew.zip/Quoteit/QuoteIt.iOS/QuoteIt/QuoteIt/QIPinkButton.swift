//
//  QIPinkButton.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-05.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

class QIPinkButton: UIButton {

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder);
        self.backgroundColor = UIColor.QIPinkColor
        self.setTitleColor(UIColor.white, for: UIControlState.normal)
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
