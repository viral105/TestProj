//
//  CategoryData.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-20.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper

class CategoryData: Mappable {
    var categoryID: Int?
    var name: String?
    var subCategoryList: [SubCategoryData]?
    
    
    required init(map: Mapper) throws {
        try categoryID = map.from("categoryID")
        name = map.optionalFrom("category")
        if let _ = name {
            
        } else {
            name = "ERROR"
        }
        
        if let _ = categoryID {
            
        } else {
            categoryID = 0
        }
        subCategoryList = map.optionalFrom("subCategoryList")
    }
}
