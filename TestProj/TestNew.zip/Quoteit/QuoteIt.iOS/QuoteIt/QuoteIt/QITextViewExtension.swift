//
//  QITextViewExtension.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-05.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import UIKit

extension UITextView {
    func addDoneToolBar() {
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.QIPinkColor
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(didPressDoneButton))
        toolBar.setItems([spaceButton, doneButton], animated: false)
        
        
        toolBar.isUserInteractionEnabled = true
        toolBar.sizeToFit()
        
        self.inputAccessoryView = toolBar
    }
    
    func didPressDoneButton() {
        self.resignFirstResponder()
    }
}
