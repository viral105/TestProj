//
//  QIView.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-06-24.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import UIKit
extension UIView {
    func loadViewFromNib() -> UIView { // grabs the appropriate bundle 
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: "\(type(of: self))", bundle: bundle)
        let view = nib.instantiate(withOwner: self, options: nil)[0] as! UIView
        return view
    }
    
    func setup() -> UIView {
        //setup the view from .xib 
        let contentView = loadViewFromNib()
        contentView.frame = self.bounds
        contentView.autoresizingMask = [UIViewAutoresizing.flexibleWidth, UIViewAutoresizing.flexibleHeight]
        addSubview(contentView)
        return contentView
    }
}
