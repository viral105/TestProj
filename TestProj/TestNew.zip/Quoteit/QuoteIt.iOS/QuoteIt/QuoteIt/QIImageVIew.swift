//
//  QIImageVIew.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-09-26.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import UIKit
import Kingfisher

extension UIImageView {
    func downloadImage(urlString: String?) {
        cancelDownload()
        if let urlString = urlString, let url = URL(string: urlString) {
            self.kf.setImage(with: url)
        }
    }
    
    func cancelDownload() {
        self.kf.cancelDownloadTask()
        self.image = nil
    }
    
}
