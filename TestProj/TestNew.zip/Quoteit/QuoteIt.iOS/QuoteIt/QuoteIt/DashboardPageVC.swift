//
//  DashboardPageVC.swift
//  QuoteIt
//
//  Created by Viral Narshana on 9/10/17.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import UIKit

protocol DashboardPageVCDelegate {
    func changeSeg(ind: Int)
}

class DashboardPageVC: UIPageViewController,DashboardPageVCDelegate {

    

    lazy var orderedViewControllers: [UIViewController] = {
        return [self.newColoredViewController(vc: "DashbMyJobsVC"),
                self.newColoredViewController(vc: "DashbHistoryVC"),
                self.newColoredViewController(vc: "DashbFavouriteVC")]
    }()

//    var orderedViewControllers = [UIViewController]()
    override func viewDidLoad() {
        super.viewDidLoad()

//        orderedViewControllers.append(self.newColoredViewController(vc: "DashbMyJobsVC"))
//        orderedViewControllers.append(self.newColoredViewController(vc: "DashbHistoryVC"))
//        orderedViewControllers.append(self.newColoredViewController(vc: "DashbFavouriteVC"))
        
//        dataSource = self
        if let firstViewController = orderedViewControllers.first {
            setViewControllers([firstViewController],
                               direction: .forward,
                               animated: true,
                               completion: nil)
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func setViewControllerFromParent(ind: Int) {
        switch ind {
        case 101:

                setViewControllers([orderedViewControllers[0]],
                                   direction: .forward,
                                   animated: true,
                                   completion: nil)

        case 102:

            setViewControllers([orderedViewControllers[1]],
                               direction: .forward,
                               animated: true,
                               completion: nil)

        case 103:

            setViewControllers([orderedViewControllers[2]],
                               direction: .forward,
                               animated: true,
                               completion: nil)
        
        default:
            print("default")
        }
    }
    private func newColoredViewController(vc: String) -> UIViewController {
        return UIStoryboard(name: "LoggedInUser", bundle: nil) .
            instantiateViewController(withIdentifier: vc)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension DashboardPageVC: UIPageViewControllerDataSource {
    
    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewControllers.index(of: viewController) else {
            return nil
        }
        
        let previousIndex = viewControllerIndex - 1
//        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "NotifId"), object: nil, userInfo: ["strInd":String(viewControllerIndex)])
        guard previousIndex >= 0 else {
            return nil
        }
        
        guard orderedViewControllers.count > previousIndex else {
            return nil
        }
        
        return orderedViewControllers[previousIndex]

    }
    
    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewControllers.index(of: viewController) else {
            return nil
        }
        
        let nextIndex = viewControllerIndex + 1
        let orderedViewControllersCount = orderedViewControllers.count
        
        guard orderedViewControllersCount != nextIndex else {
            return nil
        }
        
        guard orderedViewControllersCount > nextIndex else {
            return nil
        }
        
        return orderedViewControllers[nextIndex]

    }
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        if let identifier = viewControllers?.first?.restorationIdentifier {
            print(identifier)
//            if let index = pages.index(of: identifier) {
//                return index
//            }
        }
        return 0
    }

}
