//
//  JobViewModel.swift
//  QuoteIt
//
//  Created by Kuntal Gajjar on 2017-07-29.
//  Copyright © 2017 Kuntal Gajjar. All rights reserved.
//

import Foundation
import Mapper
class JobViewModel: Mappable {
    
    var id: Int?
    var isJobFavorite: Bool?
    var quoteId: Int?
    var userId: String?
    var title: String?
    
    var address: String?
    var lat: Double?
    var lng: Double?
    
    var category: String?
    var jobCategoryId: Int?
    var categoryThumbnail: String?
    var assignedTo: String?
    var images:[String] = []
    var poster: UserProfileViewModel?
    var assignedToSP: UserProfileViewModel?
    var description: String?
    
    var notes: String?
    var notesBySp: String?
    
    var distance: String?
    var mediaDetail: [MediaViewModel] = []
    var jobCity: String?
    var jobCityId: Int?
    var addressLine1: String?
    var addressLine2: String?
    var comments: [CommentViewModel] = []
    var quotes: [QuoteViewModel] = []
    var reviews: [ReviewViewModel] = []
    var acceptedQuote: QuoteViewModel?
    var sReview: ReviewViewModel?
    var completedBy: String?
    var lastModifiedDate: Date = Date()
    
    var quotesPosted: Int?
    var lowestQuotePrice: Float?
    var appointmentDate: String?
    var appointmentTimeFrom: String?
    var appointmentTimeTo: String?
    var isCompleted: Bool?
    var jobExpiryDate: String?
    var postedQuote: QuoteViewModel?
    var dateAcceptedByRP: Bool?
    var dateAcceptedBySP: Bool?
    var dateProposedByRP: Date = Date()
    var dateProposedBySP: Date = Date()
    var startDate: Date = Date()
    
    var acceptedQuotes: Int?
    
    
    required init(map: Mapper) throws {
        try id = map.from("id")
        isJobFavorite = map.optionalFrom("isJobFavorite")
        quoteId = map.optionalFrom("quoteId")
        userId = map.optionalFrom("userId")
        title = map.optionalFrom("title")
        
        address = map.optionalFrom("address")
        lat = map.optionalFrom("lat")
        lng = map.optionalFrom("lng")
        
        category = map.optionalFrom("category")
        jobCategoryId = map.optionalFrom("jobCategoryId")
        categoryThumbnail = map.optionalFrom("categoryThumbnail")
        assignedTo = map.optionalFrom("assignedTo")
        let imagesOptional: [String]? = map.optionalFrom("images")
        if let imagesOptional = imagesOptional {
            self.images = imagesOptional
        }
        
        poster = map.optionalFrom("poster")
        assignedToSP = map.optionalFrom("assignedToSP")
        description = map.optionalFrom("description")
        
        notes = map.optionalFrom("notes")
        notesBySp = map.optionalFrom("notesBySp")
        
        distance = map.optionalFrom("distance")
        let mediaDetailOptional: [MediaViewModel]? = map.optionalFrom("mediaDetail")
        if let mediaDetailOptional = mediaDetailOptional {
            self.mediaDetail = mediaDetailOptional
        }
        jobCity = map.optionalFrom("jobCity")
        jobCityId = map.optionalFrom("jobCityId")
        addressLine1 = map.optionalFrom("addressLine1")
        addressLine2 = map.optionalFrom("addressLine2")
        let commentsOptional: [CommentViewModel]? = map.optionalFrom("comments")
        if let commentsOptional = commentsOptional {
            self.comments = commentsOptional
        }
        let quotesOptional: [QuoteViewModel]? = map.optionalFrom("quotes")
        if let quotesOptional = quotesOptional {
            self.quotes = quotesOptional
        }
        let reviewsOptional: [ReviewViewModel]? = map.optionalFrom("reviews")
        if let reviewsOptional = reviewsOptional {
            self.reviews = reviewsOptional
        }
        sReview = map.optionalFrom("sReview")
        acceptedQuote = map.optionalFrom("acceptedQuote")
        completedBy = map.optionalFrom("completedBy")
        lastModifiedDate = map.parseDate("lastModifiedDate")
        
        quotesPosted = map.optionalFrom("quotesPosted")
        lowestQuotePrice = map.optionalFrom("lowestQuotePrice")
        appointmentDate = map.optionalFrom("appointmentDate")
        appointmentTimeFrom = map.optionalFrom("appointmentTimeFrom")
        appointmentTimeTo = map.optionalFrom("appointmentTimeTo")
        isCompleted = map.optionalFrom("isCompleted")
        jobExpiryDate = map.optionalFrom("jobExpiryDate")
        postedQuote = map.optionalFrom("postedQuote")
        dateAcceptedByRP = map.optionalFrom("dateAcceptedByRP")
        dateAcceptedBySP = map.optionalFrom("dateAcceptedBySP")
        dateProposedByRP = map.parseDate("dateProposedByRP")
        dateProposedBySP = map.parseDate("dateProposedBySP")
        startDate = map.parseDate("startDate")
        
        if poster == nil {
            poster = UserProfileViewModel()
            poster?.id = map.optionalFrom("posterId")
            poster?.avatar = map.optionalFrom("posterAvatar")
            poster?.displayName = map.optionalFrom("posterName")
        }
        
        
    }
    
    
}
